# 只能处理有官方基因名的 ENST, 没有官方名 ENST 在 step-11-enrichment 中做了( NA.gene)补全
python model/step-9-fasta-RIblast.prepare.py \
	/home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.fa \
	/home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.pc_transcripts.fa \
	/home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.lncRNA_transcripts.fa \
	/home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-5-DESeq2 \
	step-9-lncRNA.2.target 
