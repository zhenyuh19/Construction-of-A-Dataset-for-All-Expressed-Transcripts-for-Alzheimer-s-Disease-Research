#!/python
#-*-coding:utf-8-*-

import os,sys,re

GTF = sys.argv[1]
novel_lncRNA= sys.argv[2]
novel_lncRNA_dic = {}
with open(novel_lncRNA) as NOVEL_LNC:
	for ele in NOVEL_LNC:
		if re.search(r"^>", ele):
			isoform_name = ele.split(" ")[0].split(">")[1]
			novel_lncRNA_dic.setdefault(isoform_name, 1)

pattern_1 = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*gene_name \"([^\"]+).*class_code \"([^\"]+)")
pattern_2 = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*cmp_ref_gene \"([^\"]+).*class_code \"([^\"]+)")
pattern_3 = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+)")

with open(GTF) as IN, open(sys.argv[3], "w") as OUT:
	for ele in IN:
		if re.search(r"^#", ele):
			continue		

		temp = ele.strip("\n").split("\t")
#		if temp[6] == ".":		
#			continue

		if temp[2] == "transcript":
			match_1 = pattern_1.search(temp[8])
			match_2 = pattern_2.search(temp[8])	
			match_3 = pattern_3.search(temp[8])
			if novel_lncRNA_dic.get(match_3.group(1)):
				OUT.write(match_3.group(1) + "\t" + match_3.group(2) + "\n")
				continue

			if match_1:
				if match_1.group(4) == "s":
					continue
				else:
					OUT.write(match_1.group(1) + "\t" + match_1.group(3) + "\n")
			elif match_2:
				if match_2.group(4) == "s":
					continue
				else:
					OUT.write(match_2.group(1) + "\t" + match_2.group(3) + "\n")	
			elif match_3:
				OUT.write(match_3.group(1) + "\t" + match_3.group(2) + "\n")
			else:
				print("啥都没匹配到")
