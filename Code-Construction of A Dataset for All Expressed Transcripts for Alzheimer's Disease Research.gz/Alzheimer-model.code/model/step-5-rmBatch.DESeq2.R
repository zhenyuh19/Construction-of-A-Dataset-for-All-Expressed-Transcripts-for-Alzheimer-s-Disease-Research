# author : joefish
# version: v1
# modify_date : 20191119
# document: 此脚本的 batch 移除用的 RUVg 的办法, 引入 house keeping 基因进行标准化, 为避免 house keeping 基因也是差异基因，需要进行过滤

library("optparse")
# 命令行选项
option_list = list(
	make_option(c("-f", "--exp.matrix"), type = "character", default = NULL, help = "表达量矩阵文件名 [default = %default]", metavar = "character"),
	make_option(c("-s", "--sampleinfo.matrix"), type = "character", default = "NULL", help = "样本信息矩阵文件名 [default = %default]", metavar = "character"),
	make_option(c("-g", "--house.keeping.gene"), type = "character", default = NULL, help = "House Keeping 基因 [default = %default]", metavar = "character"),
	make_option(c("-x", "--group.1"), type = "character", default = NULL, help = "组 1 名 [default = %default]", metavar = "character"),
	make_option(c("-y", "--group.2"), type = "character", default = NULL, help = "组 2 名 [default = %default]", metavar = "character"),
	make_option(c("-t", "--exp.matrix.type"), type = "character", default = NULL, help = "exp.matrix type [default = %default]", metavar = "character"),
	make_option(c("-p", "--prefix"), type = "character", default = "NULL", help = "所有输出文件的相同前缀名 [default = %default]", metavar = "character"),
	make_option(c("-o", "--outdir"), type ="character", default = ".", help = "输出目录 [default= %default]", metavar = "character")
);
opt_parser = OptionParser(option_list=option_list)
opt = parse_args(opt_parser)

library('DESeq2')
library("RColorBrewer")
library("gplots")
library("amap")
library("ggplot2")
library('pheatmap')
#library('sva')
#library("RUVSeq")

# 录入数据
if(opt$exp.matrix.type == "gene"){
	readscount_df <- read.table(opt$exp.matrix, header = TRUE, stringsAsFactors = TRUE, sep = "\t", row.names = "gene_id", check.names = F)
}
if(opt$exp.matrix.type == "transcript"){
	readscount_df <- read.table(opt$exp.matrix, header = TRUE, stringsAsFactors = TRUE, sep = "\t", row.names = "transcript_id", check.names = F)
}
readscount_df <- round(readscount_df)	# 四舍五入
sampleInfo <- read.table(opt$sampleinfo.matrix, header = T, row.names = "specimenID", com = '', quote = '', check.names = F, sep = "\t", colClasses = "factor")
#gene_block <- read.table(ops[3], sep = "\t", header = TRUE)
group.1 <- opt$group.1
group.2 <- opt$group.2
outdir <- opt$outdir
prefix <- opt$prefix

# 初过滤
readscount_df <- readscount_df[rowSums(readscount_df) > 0, ]		# 每个基因所有样本的 reads 至少是 10 个

# 样本信息因子化
sample_rowname <- row.names(sampleInfo)
sample <- data.frame(lapply(sampleInfo, function(x) factor(x, levels = unique(x))))
rownames(sample) <- sample_rowname

# 初步差异分析，获取标准化结果
sampleA <- group.1
sampleB <- group.2
contrastV <- c("sample_type", sampleA, sampleB)
ddsFullCountTable <- DESeqDataSetFromMatrix(countData = readscount_df, colData = sample,  design =~ Batch + sample_type)
dds.batch <- DESeq(ddsFullCountTable)

# 差异分析
dds.no.batch <- DESeq(ddsFullCountTable, test = 'LRT', reduced =~ Batch)
#dds.no.batch <- DESeq(ddsruv, test = 'LRT', reduced =~ W1)
res <- results(dds.no.batch,  contrast = contrastV) # results函数提取差异基因分析结果，包含log2 fold changes, p values和adjusted p values

# 返回标准化的数据
normalized_counts <- counts(dds.no.batch, normalized = TRUE)

# 根据基因在不同的样本中表达变化的差异程度mad值对数据排序，差异越大的基因排位越前
normalized_counts_mad <- apply(normalized_counts, 1, mad)
normalized_counts <- normalized_counts[order(normalized_counts_mad, decreasing = T), ]

# 标准化后的数据输出
normalized.file <- paste(c(prefix, ".DESeq2.normalized.xls"), collapse = "")
normalized.file <- paste(outdir, normalized.file, sep = "/", collapse = "")
write.table(normalized_counts, file = normalized.file, quote = F, sep = "\t", row.names = T, col.names = T)
system(paste("sed -i '1 s/^/Gene\t/'", normalized.file))

# log / vst 转换
if(nrow(sampleInfo) < 30){
	normal.DESeq2 <- rlog(dds.no.batch, blind = FALSE)
}else{
	normal.DESeq2 <- vst(dds.no.batch, blind = FALSE)	# > 30个样本，用vst加速转换，且对高表达的基因不敏感
}

rlogMat <- assay(normal.DESeq2)
rlogMat <- rlogMat[order(normalized_counts_mad, decreasing = T), ]
normalized.rlog.file <- paste(c(prefix, ".DESeq2.normalized.rlog.xls"), collapse = "")
normalized.rlog.file <- paste(outdir, normalized.rlog.file, sep = "/", collapse = "")
write.table(rlogMat, file = normalized.rlog.file, quote = F, sep = "\t", row.names = T, col.names = T)
system(paste("sed -i '1 s/^/Gene\t/'", normalized.rlog.file))

# 给DESeq2的原始输出结果增加样品平均表达信息，使得结果更容易理解和解析
# 获得第一组数据均值
baseA <- counts(dds.no.batch, normalized = TRUE)[, colData(dds.no.batch)$sample_type == sampleA]
if (is.vector(baseA)){
    baseMeanA <- as.data.frame(baseA)
} else {
    baseMeanA <- as.data.frame(rowMeans(baseA))
}
colnames(baseMeanA) <- sampleA

# 获得第二组数据均值
baseB <- counts(dds.no.batch, normalized = TRUE)[, colData(dds.no.batch)$sample_type == sampleB]
if (is.vector(baseB)){
        baseMeanB <- as.data.frame(baseB)
} else {
        baseMeanB <- as.data.frame(rowMeans(baseB))
}
colnames(baseMeanB) <- sampleB

# 结果组合
res <- results(dds.no.batch,  contrast = contrastV)
res <- cbind(baseMeanA, baseMeanB, as.data.frame(res))
# 校正后p-value为NA的复制为1
res$padj[is.na(res$padj)] <- 1
# 按pvalue排序, 把差异大的基因放前面
res <- res[order(res$pvalue), ]
#整体分析结果输出到文件
#comp <- paste(sampleA, "vs", sampleB, sep = "_")
# 生成文件名
file_base <- paste(prefix, "DESeq2", sep = ".", collapse = "")
file_base1 <- paste(file_base, "results.xls", sep = ".", collapse = "")
file_base1 <- paste(outdir, file_base1, sep = "/", collapse = "")
write.table(as.data.frame(res), file = file_base1, sep = "\t", quote = F, row.names = T)
system(paste("sed -i '1 s/^/Gene\t/'", file_base1))

# 4. 提取差异表达基因
# 差异基因筛选，padj < 0.05
res_de <- subset(res, res$padj < 0.05, select = c(sampleA, sampleB, 'log2FoldChange', 'padj'))
# foldchang > 1
res_de_up <- subset(res_de, res_de$log2FoldChange >= 1)
comp <- paste(sampleA, "HigherThan", sampleB, sep = "_")
file <- paste(prefix, comp, 'xls', sep = ".", collapse = "") 
file <- paste(outdir, file, sep = "/", collapse = "")
write.table(as.data.frame(res_de_up), file = file, sep = "\t", quote = F, row.names = T)
system(paste("sed -i '1 s/^/Gene\t/'", file))
# foldchang < -1
res_de_dw <- subset(res_de, res_de$log2FoldChange <= (-1)*1)
comp <- paste(sampleA, "LowerThan", sampleB, sep = "_")
file <- paste(prefix, comp, 'xls', sep = ".", collapse = "")
file <- paste(outdir, file, sep = "/", collapse = "")
write.table(as.data.frame(res_de_dw), file = file, sep = "\t", quote = F, row.names = T)
system(paste("sed -i '1 s/^/Gene\t/'", file))

# 差异基因ID
res_de_up_id = data.frame(ID = row.names(res_de_up), type = paste(sampleA, "higherThan", sampleB, sep = "_"))
res_de_dw_id = data.frame(ID = row.names(res_de_dw), type = paste(sampleA, "lowerThan", sampleB, sep = "_"))
de_id = rbind(res_de_up_id, res_de_dw_id)
file <- paste(c(prefix, ".DESeq2.all.DE.xls"), collapse = "")
file <- paste(outdir, file, sep = "/", collapse = "")
write.table(as.data.frame(de_id), file = file, sep = "\t", quote = F, row.names = F, col.names = F)

# 绘制火山图
logCounts <- log2(res$baseMean + 1)
logFC <- res$log2FoldChange
FDR <- res$padj
outpng <- paste(file_base, "Volcano.png", sep = ".", collapse = "")
outpng <- paste(outdir, outpng, sep = "/", collapse = "")
png(outpng, w = 750, h = 750)
plot(logFC, -1*log10(FDR), col = ifelse(FDR <= 0.05, "red", "black"), xlab = "logFC", ylab = "-1*log1o(FDR)", main = "Volcano plot", pch = ".")
dev.off()

# 差异基因热图
res_de_up_top20_id <- as.vector(head(row.names(res_de_up), 20))
res_de_dw_top20_id <- as.vector(head(row.names(res_de_dw), 20))
red_de_top20 <- c(res_de_up_top20_id, res_de_dw_top20_id)
red_de_top20_expr <- normalized_counts[rownames(normalized_counts) %in% red_de_top20,]
outpng <- paste(file_base, "heatmap.png", sep = ".", collapse = "")
outpng <- paste(outdir, outpng, sep = "/", collapse = "")
png(outpng, w = 1000, h = 1000)
pheatmap(red_de_top20_expr, cluster_row = T, scale = "row", annotation_col = sample)
dev.off()

