#!/python
#-*-coding:utf-8-*-

def DESeq2_filter():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob
	import pandas as pd
	import numpy as np

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--DESEQ_RESULT', dest = 'DESeq2_result', type = 'string', help = '')
	parser.add_option('--outdir', dest = 'outdir', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest ='prefix', type = 'string', help = '')
	parser.add_option('--gene2GO_KEGG_BiGG', dest = 'gene2GO_KEGG_BiGG', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	DESeq2_result = options.DESeq2_result
	outdir = options.outdir
	prefix = options.prefix
	gene2GO_KEGG_BiGG = options.gene2GO_KEGG_BiGG

	if not outdir:
		makedir_return = os.path.isdir(outdir) or os.makedirs(outdir)

	transcript_2_eggnog = {}
	with open(gene2GO_KEGG_BiGG) as GENE2GO_KEGG_BiGG:
		for ele in GENE2GO_KEGG_BiGG:
			temp = ele.strip("\n").split("\t")
			if temp[0] != "query_name":
				transcript_2_eggnog.setdefault(temp[0], {})
				transcript_2_eggnog[temp[0]].setdefault("gene", temp[1])
				transcript_2_eggnog[temp[0]].setdefault("genedeps", temp[2])
				transcript_2_eggnog[temp[0]].setdefault("kegg_reaction", temp[-2])

	DESeq2_result_add_gene = outdir + "/" + prefix + ".xls"	
	with open(DESeq2_result) as IN, open(DESeq2_result_add_gene, "w") as OUT:
		for ele in IN:
			temp = ele.strip("\n").split("\t")
			col2_ = "\t".join(temp[1:])
			if re.search(r"Gene", ele):
				OUT.write("transcript\tGene\t" + col2_ + "\n")
			else:
				if transcript_2_eggnog.get(temp[0]):
					OUT.write(temp[0] + "\t" + transcript_2_eggnog.get(temp[0]).get("gene") + "\t" + col2_ + "\n")
				else:
					print("没有转录本")



if __name__ == '__main__':
	'''
	'''	

	DESeq2_filter()

