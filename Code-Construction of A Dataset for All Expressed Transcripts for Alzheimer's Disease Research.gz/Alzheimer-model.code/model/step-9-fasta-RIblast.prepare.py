#!/python
#-*-coding:utf-8-*-

import os,re,sys,glob
import pandas as pd

stringtie_merged_fa = sys.argv[1]
gencode_pc_transcripts_fa = sys.argv[2]
gencode_lncRNA_transcripts_fa = sys.argv[3]
DESeq2_input = sys.argv[4]
outdir = sys.argv[5]

# 对表达的基因进行过滤 (要求 case 组至少 1/3 的样本都表达)
filter_gene = {}
for par, dirs, files in os.walk(DESeq2_input):
	for subfile in files:
		inputfile = par + "/" + subfile
		if re.search(r"Clinical.Info.csv$", subfile):
			basename = subfile.split(".")[0]
			case_name = basename.split("_vs_")[0]
			control_name = basename.split("_vs_")[1]

			Clinical_info_df = pd.read_csv(inputfile, sep = "\t")
			case_specimenID = Clinical_info_df['specimenID'][Clinical_info_df['sample_type'] == case_name]
			control_specimenID = Clinical_info_df['specimenID'][Clinical_info_df['sample_type'] == control_name]
			case_filter_index = len(case_specimenID) / 5	# 1/2的样本
			control_filter_index = len(control_specimenID) / 5

			stringtie_transcript_count = par + "/" + basename + ".transcript.stringtie.transcript.csv"
			stringtie_transcript_count_df = pd.read_csv(stringtie_transcript_count, sep = "\t", index_col = "transcript_id")	

			case_df = stringtie_transcript_count_df[case_specimenID]
			case_df[case_df > 0] = 1
			case_df_dict = case_df.sum(1).to_dict()
			for ele in case_df_dict:
				if case_df_dict.get(ele) >= case_filter_index:
					filter_gene.setdefault(ele, 1)

			control_df = stringtie_transcript_count_df[control_specimenID]
			control_df[control_df > 0] = 1
			control_df_dict = control_df.sum(1).to_dict()
			for ele in control_df_dict:
				if control_df_dict.get(ele) >= control_filter_index:
					filter_gene.setdefault(ele, 1)

lncRNA_id = {}
pcRNA_id = {}
for par, dirs, files in os.walk(DESeq2_input):
	for subfile in files:
		inputfile = par + "/" + subfile
		if re.search(r"transcript.DESeq2.SignificanceDiff.lncRNA.xls$", subfile):
			with open(inputfile) as IN:
				for ele in IN:
					if re.search(r"Gene", ele):
						continue
					else:
						temp = ele.strip("\n").split("\t")
						if filter_gene.get(temp[0]):	# 满足样本要求
							lncRNA_id.setdefault(temp[0], 1)

		if re.search(r"(transcript.DESeq2.SignificanceDiff.pcRNA.xls$)|(transcript.DESeq2.SignificanceDiff.restRNA.xls$)|(transcript.DESeq2.SignificanceDiff.newRNA.xls)", subfile):
			with open(inputfile) as IN:
				for ele in IN:
					if re.search(r"Gene", ele):
						continue
					else:
						temp = ele.strip("\n").split("\t")
						if filter_gene.get(temp[0]):	# 满足样本要求
							pcRNA_id.setdefault(temp[0], 1)	

fasta = {}
with open(stringtie_merged_fa, "r") as STRINGTIE, open(gencode_pc_transcripts_fa) as GENCODE, open(gencode_lncRNA_transcripts_fa) as GENCODE_LNC:
	flag = True
	transcript_name = []
	for ele in STRINGTIE:	# STRINGTIE 的注释文件只需要 新的 MSTRG 标注的转录本
		if re.search(r"^>ENST0", ele):	# ENST0转录本用 GENCODE 版本更可信
			flag = False

		if re.search(r"^>MSTRG", ele):
			basename = ele.strip("\n").split(" ")[0].split(">")[1]
			transcript_name.append(basename)
			flag = True
			fasta.setdefault(basename, "")
		else:			
			if flag:
				sequece = fasta.get(transcript_name[-1]) + ele
				fasta[transcript_name[-1]] = sequece
		
	transcript_name = []		
	for ele in GENCODE:
		if re.search(r"^>ENST0", ele):
			basename = ele.strip("\n").split("|")[0].split(">")[1]
			transcript_name.append(basename)
			fasta.setdefault(basename, "")
		else:
			sequece = fasta.get(transcript_name[-1]) + ele
			fasta[transcript_name[-1]] = sequece	

	transcript_name = []
	for ele in GENCODE_LNC:
		if re.search(r"^>ENST0", ele):
			basename = ele.strip("\n").split("|")[0].split(">")[1]
			transcript_name.append(basename)
			fasta.setdefault(basename, "")
		else:
			sequece = fasta.get(transcript_name[-1]) + ele
			fasta[transcript_name[-1]] = sequece

lncRNA_fa_out = outdir + "/Diff_LncRNA.fa"
pcRNA_fa_out = outdir + "/Diff_pcRNA.fa"
with open(lncRNA_fa_out, "w") as LNCRNA, open(pcRNA_fa_out, "w") as PCRNA:	
	for ele in lncRNA_id:
		if fasta.get(ele):
			LNCRNA.write(">" + ele + "\n" + fasta.get(ele))
	for ele in pcRNA_id:
		if fasta.get(ele):
			PCRNA.write(">" + ele + "\n" + fasta.get(ele))

