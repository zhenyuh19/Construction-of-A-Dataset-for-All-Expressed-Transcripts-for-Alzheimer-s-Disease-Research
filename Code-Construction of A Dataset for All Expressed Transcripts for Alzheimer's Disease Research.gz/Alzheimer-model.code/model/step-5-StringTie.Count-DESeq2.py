#!/python
#-*-coding:utf-8-*-

import pandas as pd
import os,re,sys

def DESeq2():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--stringtie_gene_count', dest = 'stringtie_gene_count', type = 'string', help = '')
	parser.add_option('--stringtie_transcript_count', dest = 'stringtie_transcript_count', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest ='prefix', type = 'string', help = '')
	parser.add_option('--biospecimen', dest = 'biospecimen', type = 'string', help = '')
	parser.add_option('--ROSMAP_Clinical', dest ='ROSMAP_Clinical', type = 'string', help = '')	
	parser.add_option('--metadata', dest ='metadata', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	stringtie_gene_count = options.stringtie_gene_count
	stringtie_transcript_count = options.stringtie_transcript_count
	output = options.output
	prefix = options.prefix
	biospecimen = options.biospecimen
	ROSMAP_Clinical = options.ROSMAP_Clinical
	RNAseq_metadata = options.metadata

	if not os.path.exists(output):
		makedir_return = os.path.isdir(output) or os.makedirs(output)

	stringtie_gene_count_df = pd.read_csv(stringtie_gene_count, index_col = "gene_id")
	stringtie_transcript_count_df = pd.read_csv(stringtie_transcript_count, index_col = "transcript_id")
	biospecimen_df = pd.read_csv(biospecimen, index_col = "individualID")
#	biospecimen_df = biospecimen_df[~biospecimen_df.index.duplicated(keep=False)]	# 去除有重复 individualID 的样本, 这里已人工删除了样本
	ROSMAP_Clinical_df = pd.read_csv(ROSMAP_Clinical, index_col = "individualID")
	ROSMAP_Clinical_df = ROSMAP_Clinical_df.drop(['R1435458', 'R6284240', 'R5009796'])	# 去除不要的样本
	RNAseq_metadata_df = pd.read_csv(RNAseq_metadata, index_col = 'specimenID')
	RNAseq_metadata_df = RNAseq_metadata_df.dropna(subset = ['notes'])
	RNAseq_metadata_df = RNAseq_metadata_df[~RNAseq_metadata_df.index.duplicated(keep = 'first')]	# 保存第一个样本的 batch 信息

	def make_DESeq2(ExpMatrix, SampleinfoMatrix, Group1Name, Group2Name, prefix, outdir, exp_matrix_type):
		shell1 = '''/home/hcy/software/R_conda/bin/Rscript /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/model/step-5-rmBatch.DESeq2.R \\
	--exp.matrix {_ExpMatrix} \\
	--sampleinfo.matrix {_SampleinfoMatrix} \\
	--group.1 {_Group1Name} \\
	--group.2 {_Group2Name} \\
	--prefix {_prefix} \\
	--exp.matrix.type {_exp_matrix_type} \\
	--outdir {_outdir}

'''.format(_ExpMatrix = ExpMatrix, _SampleinfoMatrix = SampleinfoMatrix, _Group1Name = Group1Name, _Group2Name = Group2Name, _prefix = prefix, _outdir = outdir, _exp_matrix_type = exp_matrix_type)

		if exp_matrix_type == "gene":
			shell2 = '''
python /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/model/step-5-Diff.Gene.result.modify.py \\
    --DESEQ_RESULT {_outdir}/{_prefix}.DESeq2.results.xls \\
    --pvalue 0.05 \\
    --foldchange 0.263034 \\
    --outdir {_outdir} \\
    --gencode_gtf /home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.primary_assembly.annotation.gtf \\
    --novel_lncgtf /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-8-venn.2.lncRNAstat/novel.lnc.gff \\
    --Enzymatic_Reactions_keg /home/hcy/database/KEGG/2020-10-25/Enzymatic.Reactions.keg \\
    --gene2GO_KEGG_BiGG /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-2-DPFC-StringTie-merge/step-1-eggnog-mapper/step-2-cat.annotation/gene2GO.KEGG.BiGG.supplement

/home/hcy/software/R_conda/bin/Rscript /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/model/step-5-enrichment.clusterprofiler.R \\
	--DESEQ2_allgene {_outdir}/{_prefix}.DESeq2.results.preRANK.2.enrichment.xls \\
	--DESEQ2_UP {_outdir}/{_prefix}.DESeq2.SignificanceDiff.coding.UP.xls \\
	--DESEQ2_DOWN {_outdir}/{_prefix}.DESeq2.SignificanceDiff.coding.DOWN.xls \\
	--prefix {_prefix} \\
	--outdir {_outdir} \\
	--gene2annot /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-2-DPFC-StringTie-merge/step-1-eggnog-mapper/step-2-cat.annotation/gene2GO.KEGG.BiGG.RData

'''.format(_prefix = prefix, _outdir = outdir)
		
		if exp_matrix_type == "transcript":
			shell2 = '''
python /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/model/step-5-Diff.transcript.result.modify.py \\
    --DESEQ_RESULT {_outdir}/{_prefix}.DESeq2.results.xls \\
    --pvalue 0.05 \\
    --foldchange 0.263034 \\
    --outdir {_outdir} \\
    --gencode_gtf /home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.primary_assembly.annotation.gtf \\
    --novel_lncgtf /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-8-venn.2.lncRNAstat/novel.lnc.gff \\
    --Enzymatic_Reactions_keg /home/hcy/database/KEGG/2020-10-25/Enzymatic.Reactions.keg \\
    --gene2GO_KEGG_BiGG /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-2-DPFC-StringTie-merge/step-1-eggnog-mapper/step-2-cat.annotation/gene2GO.KEGG.BiGG.supplement

/home/hcy/software/R_conda/bin/Rscript /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/model/step-5-enrichment.clusterprofiler.R \\
    --DESEQ2_allgene {_outdir}/{_prefix}.DESeq2.results.preRANK.2.enrichment.xls \\
    --DESEQ2_UP {_outdir}/{_prefix}.DESeq2.SignificanceDiff.coding.UP.xls \\
    --DESEQ2_DOWN {_outdir}/{_prefix}.DESeq2.SignificanceDiff.coding.DOWN.xls \\
    --prefix {_prefix} \\
    --outdir {_outdir} \\
    --gene2annot /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-2-DPFC-StringTie-merge/step-1-eggnog-mapper/step-2-cat.annotation/gene2GO.KEGG.BiGG.RData

'''.format(_prefix = prefix, _outdir = outdir)

		if exp_matrix_type == "gene":
			shell3 = '''
python /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/model/step-5-lncRNA.gene.diff.py \\
    /home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.primary_assembly.annotation.gff3 \\
    /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-8-venn.2.lncRNAstat/novel.lnc.gff \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.trname.xls \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.lncRNA.xls \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.pcRNA.xls \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.restRNA.xls

'''.format(_prefix = prefix, _outdir = outdir)

		if exp_matrix_type == "transcript":
			shell3 = '''
python /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/model/step-5-lncRNA.transcript.diff.py \\
    /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-6-gffcompare.2.filter.2.fastadraw/merged.annotated.transcript-2-genename.txt \\
    /home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.primary_assembly.annotation.gtf \\
    /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-8-venn.2.lncRNAstat/novel.lnc.gtf \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.trname.xls \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.lncRNA.xls \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.pcRNA.xls \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.restRNA.xls \\
    {_outdir}/{_prefix}.DESeq2.SignificanceDiff.newRNA.xls \\
    {_outdir}
	
'''.format(_prefix = prefix, _outdir = outdir)

		shell = shell1 + shell2 + shell3

		return shell

	dcfdx_level_list = sorted(ROSMAP_Clinical_df['dcfdx_lv'].unique())
	dcfdx_level_record = []
	for dcfdx1 in dcfdx_level_list:
		dcfdx_level_record.append(dcfdx1)
		for dcfdx2 in dcfdx_level_list:
			if dcfdx2 not in dcfdx_level_record:
				dcfdx2_individualID = ROSMAP_Clinical_df[ROSMAP_Clinical_df['dcfdx_lv'] == dcfdx2].index.tolist()
				dcfdx1_individualID = ROSMAP_Clinical_df[ROSMAP_Clinical_df['dcfdx_lv'] == dcfdx1].index.tolist()
				dcfdx2_vs_dcfdx1 = dcfdx2_individualID + dcfdx1_individualID
				dcfdx2_vs_dcfdx1_Clinical_df = ROSMAP_Clinical_df.loc[dcfdx2_vs_dcfdx1]

				NONE_specimenID =  biospecimen_df.loc[dcfdx2_vs_dcfdx1]['specimenID'].fillna("NONE-specimenID")	# dcfdx2_vs_dcfdx1_Clinical_df 中有些 individualID 没有 specimenID, 找到删了
				NONE_specimenID_individualID = NONE_specimenID[NONE_specimenID == "NONE-specimenID"].index.tolist()
				dcfdx2_vs_dcfdx1_Clinical_df = dcfdx2_vs_dcfdx1_Clinical_df.drop(NONE_specimenID_individualID)

				dcfdx2_vs_dcfdx1_specimenID = biospecimen_df.loc[dcfdx2_vs_dcfdx1]['specimenID'].dropna().tolist()
				dcfdx2_vs_dcfdx1_stringtie_gene_count_df = stringtie_gene_count_df[dcfdx2_vs_dcfdx1_specimenID]
				dcfdx2_vs_dcfdx1_stringtie_transcript_count_df = stringtie_transcript_count_df[dcfdx2_vs_dcfdx1_specimenID]

				dcfdx2_vs_dcfdx1_batch = RNAseq_metadata_df.loc[dcfdx2_vs_dcfdx1_specimenID]['notes'].tolist()
				dcfdx2_vs_dcfdx1_Clinical_df['Batch'] = dcfdx2_vs_dcfdx1_batch
				dcfdx2_vs_dcfdx1_Clinical_df['specimenID'] = dcfdx2_vs_dcfdx1_specimenID

				dcfdx2_vs_dcfdx1_Clinical_df['sample_type'] = "NA"
				dcfdx2_vs_dcfdx1_Clinical_df['sample_type'][dcfdx2_vs_dcfdx1_Clinical_df['dcfdx_lv'] == 1.0] = "Normal"
				dcfdx2_vs_dcfdx1_Clinical_df['sample_type'][dcfdx2_vs_dcfdx1_Clinical_df['dcfdx_lv'] == 2.0] = "MCI"
				dcfdx2_vs_dcfdx1_Clinical_df['sample_type'][dcfdx2_vs_dcfdx1_Clinical_df['dcfdx_lv'] == 3.0] = "MCI+"
				dcfdx2_vs_dcfdx1_Clinical_df['sample_type'][dcfdx2_vs_dcfdx1_Clinical_df['dcfdx_lv'] == 4.0] = "AD"
				dcfdx2_vs_dcfdx1_Clinical_df['sample_type'][dcfdx2_vs_dcfdx1_Clinical_df['dcfdx_lv'] == 5.0] = "AD+"
				dcfdx2_vs_dcfdx1_Clinical_df['sample_type'][dcfdx2_vs_dcfdx1_Clinical_df['dcfdx_lv'] == 6.0] = "Other"

				if dcfdx1 == 3.0 or dcfdx1 == 5.0 or dcfdx1 == 6.0 or dcfdx2 == 3.0 or dcfdx2 == 5.0 or dcfdx2 == 6.0:
					continue

				if dcfdx1 == 1.0:
					group1 = "Normal"
				elif dcfdx1 == 2.0:
					group1 = "MCI"
				elif dcfdx1 == 3.0:
					group1 = "MCI+"
				elif dcfdx1 == 4.0:
					group1 = "AD"
				elif dcfdx1 == 5.0:
					group1 = "AD+"
				elif dcfdx1 == 6.0:
					group1 = "Other"

				if dcfdx2 == 1.0:
					group2 = "Normal"
				elif dcfdx2 == 2.0:
					group2 = "MCI"
				elif dcfdx2 == 3.0:
					group2 = "MCI+"
				elif dcfdx2 == 4.0:
					group2 = "AD"
				elif dcfdx2 == 5.0:
					group2 = "AD+"
				elif dcfdx2 == 6.0:
					group2 = "Other"

				prefix = group2 + "_vs_" + group1
				prefix_oudir = output + "/" + prefix
				if not os.path.exists(prefix_oudir):
					makedir_return = os.path.isdir(prefix_oudir) or os.makedirs(prefix_oudir)
				
				prefix_gene_name = group2 + "_vs_" + group1 + ".Gene"
				dcfdx2_vs_dcfdx1_stringtie_gene_count_oufile = prefix_oudir + "/" + prefix_gene_name + ".stringtie.count.csv"
				dcfdx2_vs_dcfdx1_stringtie_gene_count_df.to_csv(dcfdx2_vs_dcfdx1_stringtie_gene_count_oufile, sep = "\t")

				prefix_transcript_name = group2 + "_vs_" + group1 + ".transcript"
				dcfdx2_vs_dcfdx1_stringtie_transcript_count_oufile = prefix_oudir + "/" + prefix_transcript_name + ".stringtie.transcript.csv"
				dcfdx2_vs_dcfdx1_stringtie_transcript_count_df.to_csv(dcfdx2_vs_dcfdx1_stringtie_transcript_count_oufile, sep = "\t")

				dcfdx2_vs_dcfdx1_Clinical_outfile = prefix_oudir + "/" + group2 + "_vs_" + group1 + ".Clinical.Info.csv"
				dcfdx2_vs_dcfdx1_Clinical_df.to_csv(dcfdx2_vs_dcfdx1_Clinical_outfile, sep = "\t")

				Gene_DESeq2_sh = make_DESeq2(ExpMatrix = dcfdx2_vs_dcfdx1_stringtie_gene_count_oufile, SampleinfoMatrix = dcfdx2_vs_dcfdx1_Clinical_outfile, Group1Name = group2, Group2Name = group1, prefix = prefix_gene_name, outdir = prefix_oudir, exp_matrix_type = "gene")
				transcript_DESeq2_sh = make_DESeq2(ExpMatrix = dcfdx2_vs_dcfdx1_stringtie_transcript_count_oufile, SampleinfoMatrix = dcfdx2_vs_dcfdx1_Clinical_outfile, Group1Name = group2, Group2Name = group1, prefix = prefix_transcript_name, outdir = prefix_oudir, exp_matrix_type = "transcript")
			
				GENE_shell = "{_output}/{_prefix_gene_name}.DESeq2.sh".format(_output = prefix_oudir, _prefix_gene_name = prefix_gene_name)	
				TRANS_shell = "{_output}/{_prefix_transcript_name}.DESeq2.sh".format(_output = prefix_oudir, _prefix_transcript_name = prefix_transcript_name)
				with open(GENE_shell, "w") as GENE_SH, open(TRANS_shell, "w") as TRANS_SH: 
					GENE_SH.write(Gene_DESeq2_sh)
					TRANS_SH.write(transcript_DESeq2_sh)

#					os.system("cd {_output} && nohup sh {_output_shell} > {_output_shell}.o 2 > {_output_shell}.e &".format(_output_shell = GENE_shell, _output = prefix_oudir))
#					os.system("cd {_output} && nohup sh {_output_shell} > {_output_shell}.o 2 > {_output_shell}.e &".format(_output_shell = TRANS_shell, _output = prefix_oudir))


if __name__ == '__main__':
	'''
	'''	

	DESeq2()


