#!/python
#-*-coding:utf-8-*-

import os,sys,re

# 差异 lncRNA 的 差异 pc 靶基因, 这不能说明差异的靶基因
# 有待商榷

novel_lncRNA = sys.argv[1]
novel_lncRNA_dic = {}
with open(novel_lncRNA) as NOVEL_LNC:
	for ele in NOVEL_LNC:
		if re.search(r"^>", ele):
			isoform_name = ele.split(" ")[0].split(">")[1]
			novel_lncRNA_dic.setdefault(isoform_name, 1)

GENCODE_GTF = sys.argv[2]
STRINGTIE_compGTF = sys.argv[3]
with open(GENCODE_GTF) as GENCODE_GTF_HD, open(STRINGTIE_compGTF) as STRINGTIE_compGTF_HD:
	transcript_2_genename_dic = {}	# 转录本名 => 基因名
	gene_dic = {}

	pattern_GENCODE_genename = re.compile(r"gene_name \"([^\"]+)")
	pattern_GENCODE1 = re.compile(r"transcript_id \"([^\"]+).*gene_name \"([^\"]+)")
	for ele in GENCODE_GTF_HD:
		if re.search(r"^#", ele):
			continue

		temp = ele.strip("\n").split("\t")
		match0 = pattern_GENCODE_genename.search(temp[8])
		gene_dic.setdefault(match0.group(1), "")
		gene_dic[match0.group(1)] += ele

		match1 = pattern_GENCODE1.search(temp[8])
		if match1:
			transcript_2_genename_dic.setdefault(match1.group(1), match1.group(2))	# 转录本名 => 基因名

	class_code_u = {}
	class_code_u_transcript_2_gene_dic = {}
	pattern_transcript_gene_name = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*gene_name \"([^\"]+).*class_code \"([^\"]+).")
	pattern_transcript_cmp_ref_gene = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*class_code \"([^\"]+).*cmp_ref_gene \"([^\"]+)")
	pattern_transcript_class_code = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*class_code \"([^\"]+)")
	pattern_exon = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+)")
	pattern_ENST = re.compile(r"transcript_id \"ENST0")
	for ele in STRINGTIE_compGTF_HD:
		temp = ele.strip("\n").split("\t")
		match_transcript_gene_name = pattern_transcript_gene_name.search(temp[8])
		match_transcript_cmp_ref_gene = pattern_transcript_cmp_ref_gene.search(temp[8])
		match_transcript_class_code = pattern_transcript_class_code.search(temp[8])
		match_exon = pattern_exon.search(temp[8])
		match_ENST = pattern_ENST.search(temp[8])

		# stringtie 中的 ENST 转录本不做记录
		if match_ENST:
			continue
		
		if temp[2] == "transcript":
			# 1 优先匹配 novel_lncRNA_dic 里的转录本 id, 用 pattern_exon (一起抓 lncRNA 的 transcript 和 exon 行), 且可能是新的lncRNA 的原 genename 是 pcRNA
			if novel_lncRNA_dic.get(match_exon.group(1)):
				gene_dic.setdefault(match_exon.group(2), "")
				gene_dic[match_exon.group(2)] += ele
				class_code_u_transcript_2_gene_dic.setdefault(match_exon.group(1), match_exon.group(2))

			# 2 不在 novel_lncRNA_dic 中, class_code = u时, 没有gene_name 或 cmp_ref_gene, 但是在class_code = u的 geneid 的其他class_code，则有gene_name 或 cmp_ref_gene. 则需要单独在 gene_dic 构建 geneid
			elif match_transcript_class_code.group(3) == "u":
				gene_dic.setdefault(match_transcript_class_code.group(2), "")
				gene_dic[match_transcript_class_code.group(2)] += ele
				class_code_u_transcript_2_gene_dic.setdefault(match_transcript_class_code.group(1), match_transcript_class_code.group(2))
			
			# 3 抓取有 gene_name 的 transcript_id
			elif match_transcript_gene_name:
				gene_dic.setdefault(match_transcript_gene_name.group(3), "")
				gene_dic[match_transcript_gene_name.group(3)] += ele
				transcript_2_genename_dic.setdefault(match_transcript_gene_name.group(1), match_transcript_gene_name.group(3))

			# 4 抓取有 cmp_ref_gene 的 transcript_id
			elif match_transcript_cmp_ref_gene:
				gene_dic.setdefault(match_transcript_cmp_ref_gene.group(4), "")
				gene_dic[match_transcript_cmp_ref_gene.group(4)] += ele
				transcript_2_genename_dic.setdefault(match_transcript_cmp_ref_gene.group(1), match_transcript_cmp_ref_gene.group(4))


			# 5 抓取没有 gene_name , cmp_ref_gene 的 transcript_id: 基本上只有 class code u 才没有, 但是已被第二个
			elif match_transcript_class_code:	
				print("stringtie 出现 class code 非 u 但是没有 gene_name , cmp_ref_gene 的转录本\n")

		elif temp[2] == "exon":
			# 6 exon 区, 执行添加优先判断 class_code_u_transcript_2_gene_dic 
			if match_exon:
				if class_code_u_transcript_2_gene_dic.get(match_exon.group(1)):
					gene_dic[class_code_u_transcript_2_gene_dic.get(match_exon.group(1))] += ele	

				elif transcript_2_genename_dic.get(match_exon.group(1)):	# 已经记录了 转录本信息(针对 exon, 新 lncRNA 行)
					gene_dic[transcript_2_genename_dic.get(match_exon.group(1))] += ele
				else:
					print("怪异")
		else:
			print("啥都没匹配到", ele )

################## 有待优化 ：有些预测的 lncRNA 的refname 是 pcRNA

DESeq2_resdir = sys.argv[4]
lncRNA_id = {}
pcRNA_id = {}
for par, dirs, files in os.walk(DESeq2_resdir):
	for subfile in files:
		inputfile = par + "/" + subfile
		if re.search(r"transcript.DESeq2.SignificanceDiff.lncRNA.xls$", subfile):
			with open(inputfile) as IN:
				for ele in IN:
					if re.search(r"Gene", ele):
						continue
					else:
						temp = ele.strip("\n").split("\t")
						lncRNA_id.setdefault(temp[0].strip(" "), 1)

		if re.search(r"(transcript.DESeq2.SignificanceDiff.pcRNA.xls$)|(transcript.DESeq2.SignificanceDiff.restRNA.xls$)|(transcript.DESeq2.SignificanceDiff.newRNA.xls)", subfile):
			with open(inputfile) as IN:
				for ele in IN:
					if re.search(r"Gene", ele):
						continue
					else:
						temp = ele.strip("\n").split("\t")
						pcRNA_id.setdefault(temp[0].strip(" "), 1)	

#print(lncRNA_id.get("MSTRG.24032.6"))
#print(gene_dic.get("MSTRG.36415"))

outdir = sys.argv[5]
lncRNA_gtf_out = outdir + "/Diff_lncRNA.gtf"
pcRNA_gtf_out = outdir + "/Diff_pcRNA.gtf"
with open(lncRNA_gtf_out, "w") as LNCRNA, open(pcRNA_gtf_out, "w") as PCRNA:	
	for ele in lncRNA_id:
		if class_code_u_transcript_2_gene_dic.get(ele):
			if gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)):
				LNCRNA.write(gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)))
			else:
				print("class_code_u 没有")
		elif transcript_2_genename_dic.get(ele):
			if gene_dic.get(transcript_2_genename_dic.get(ele)):
				LNCRNA.write(gene_dic.get(transcript_2_genename_dic.get(ele)))
			else:
				print("{_ele}==> lncRNA 有基因名 ==> {_geneid}, 但 GTF文件没有 ====> ".format(_ele = ele, _geneid = transcript_2_genename_dic.get(ele)), gene_dic.get(transcript_2_genename_dic.get(ele)))
		else:
			print(ele, " 不存在基因名")			

	for ele in pcRNA_id:
		if class_code_u_transcript_2_gene_dic.get(ele):
			if gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)):
				PCRNA.write(gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)))
			else:
				print("class_code_u 没有")
		elif transcript_2_genename_dic.get(ele):
			if gene_dic.get(transcript_2_genename_dic.get(ele)):
				PCRNA.write(gene_dic.get(transcript_2_genename_dic.get(ele)))
			else:
				print("{_ele}==> pcRNA 有基因名 ==> {_geneid}, 但 GTF文件没有 ===> ".format(_ele = ele, _geneid = transcript_2_genename_dic.get(ele)), gene_dic.get(transcript_2_genename_dic.get(ele)))
		else:
			print(ele, " 不存在基因名")


