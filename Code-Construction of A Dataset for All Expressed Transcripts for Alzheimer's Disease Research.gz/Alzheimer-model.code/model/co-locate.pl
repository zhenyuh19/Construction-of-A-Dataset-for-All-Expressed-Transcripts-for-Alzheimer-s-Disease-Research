#!/usr/bin/perl -w
use strict;
use Getopt::Long;

my ($prefix, $mrnagff, $lncgff, $diff, $flank, $help);
GetOptions(
			"p:s" => \$prefix,
			"m:s" => \$mrnagff,
			"l:s" => \$lncgff,
			"d:s" => \$diff,
			"f:i" => \$flank,
			"h|?" => \$help,
);

$flank  ||= 10000;

if(!$prefix || !$mrnagff || !$lncgff || !$diff || $help){
	die &USAGE;
}

my %gff_region;
my %length;
my %diff;

### 读取差异的 lncRNA 基因( 考虑是否要换转录本 )
open DIFF,"$diff" or die "[ERROR] file $diff open failed!\n";
<DIFF>;
while (<DIFF>){
	chomp;
	my @tmp=split /\t/;
	$diff{$tmp[0]}=1;
}
close DIFF;

# 读取编码蛋白基因 gtf 文件
open CGFF, "<$mrnagff" or die "[ERROR] file $mrnagff open failed!\n";
while(<CGFF>){
	chomp;
	next if(/^#/ || /^\s*$/);
	my @arry = split /\s+/;
	if($arry[2] eq "gene"){	# 匹配到基因行
		my $up_start   = 0;
		my $up_end     = 0;
		my $mRNA_start = $arry[3];
		my $mRNA_end   = $arry[4];
		my $down_start = 0;
		my $down_end   = 0;
		my $mRNA_name  = "";
		if($arry[8] =~ /ID=([^;]+)/){		# 查看基因
			$mRNA_name = $1;
		}else{
			die "[ERROR] can't get gene name from ($arry[8])!\n";
		}
		if($arry[6] eq "+"){
			$up_start   = $mRNA_start-$flank;
			$up_end     = $mRNA_start-1;
			$down_start = $mRNA_end+1;
			$down_end   = $mRNA_end+$flank;
		}elsif($arry[6] eq "-"){
			$up_start   = $mRNA_end+1;
			$up_end     = $mRNA_end+$flank;
			$down_start = $mRNA_start-$flank;
			$down_end   = $mRNA_start-1;
		}else{die "[ERROR] strand info not equal +/-!\n";}
		push @{$gff_region{$arry[0]}->{$mRNA_name}->{"UP"}},($arry[6],$up_start,$up_end,$arry[0],$mRNA_start,$mRNA_end);	# chr -> gene name -> "UP" -> [strand, up_start, up_end, chromesome, mRNA_start, mRNA_end]
		push @{$gff_region{$arry[0]}->{$mRNA_name}->{"DOWN"}},($arry[6],$down_start, $down_end,$arry[0],$mRNA_start,$mRNA_end);
	}
}
close CGFF;

open TARGRT, ">$prefix\_lncRNA.cis.target.xls" or die "[ERROR] file $prefix\_lncRNA.cis.target.xls create failed!\n";
print TARGRT join("\t", "lncRNA", "chr","strand","start","end","mRNA","chr","strand","start","end","UP/DOWN","distance\n");

open LNC,"<$lncgff" or die "[ERROR] file $lncgff open failed!\n";
while(<LNC>){
	chomp;
	next if(/^#/ || /^\s*$/ || /^chr\s+/);
	my @arry = split /\s+/;
	my $tag;
	if($arry[2] eq "gene"){	
		if($arry[8] =~ /ID=([^;]+)/){	
            my $lncRNA_name = $1;
            if(exists $gff_region{$arry[0]} && exists $diff{$lncRNA_name}){	# 染色体是否存在, 且是否为差异 lncRNA 基因
				my $lnc_start=$arry[3];
				my $lnc_end=$arry[4];
        	   	my $strand=$arry[6];
				my $flank=$flank/1000;
				$tag = region($gff_region{$arry[0]},$strand,$lnc_start,$lnc_end,$flank,$lncRNA_name,$arry[0],$strand,$lnc_start,$lnc_end);
			}
		}else{
                die "[ERROR] can't get gene name from ($arry[8])!\n";
        }
	}
}
close LNC;

close TARGRT;

# Sub functions
sub region{
	my ($gff_chr,$strand,$start,$end,$flk,$lncRNA_name,$lnc_chr,$lnc_strand,$lnc_start,$lnc_end) = @_;
	my $distance;
	foreach my $name (sort keys %$gff_chr){
		my $tag="";
		if ($strand eq "+"){
			if($strand eq ${$gff_chr->{$name}->{"UP"}}[0] and $end >=${$gff_chr->{$name}->{"UP"}}[1] and $end<=${$gff_chr->{$name}->{"UP"}}[2]){
		     	$distance=${$gff_chr->{$name}->{"UP"}}[2]-$end+1;   	
				$tag = $lncRNA_name."\t".$lnc_chr."\t".$lnc_strand."\t".$lnc_start."\t".$lnc_end."\t".$name."\t".${$gff_chr->{$name}->{"UP"}}[3]."\t".$strand."\t".${$gff_chr->{$name}->{"UP"}}[4]."\t".${$gff_chr->{$name}->{"UP"}}[5]."\tUp".$flk."K\t".$distance;
			}elsif($strand eq ${$gff_chr->{$name}->{"DOWN"}}[0] and $start>=${$gff_chr->{$name}->{"DOWN"}}[1] and $start<=${$gff_chr->{$name}->{"DOWN"}}[2]){          			
				$distance=$start-${$gff_chr->{$name}->{"DOWN"}}[1]+1;
				$tag = $lncRNA_name."\t".$lnc_chr."\t".$lnc_strand."\t".$lnc_start."\t".$lnc_end."\t".$name."\t".${$gff_chr->{$name}->{"DOWN"}}[3]."\t".$strand."\t".${$gff_chr->{$name}->{"DOWN"}}[4]."\t".${$gff_chr->{$name}->{"DOWN"}}[5]."\tDown".$flk."K\t".$distance;				
			}
		}elsif($strand eq "-"){
            if($strand eq ${$gff_chr->{$name}->{"UP"}}[0] and $start >= ${$gff_chr->{$name}->{"UP"}}[1] and $start <= ${$gff_chr->{$name}->{"UP"}}[2]){
				$distance=$start-${$gff_chr->{$name}->{"UP"}}[1]+1;
				$tag = $lncRNA_name."\t".$lnc_chr."\t".$lnc_strand."\t".$lnc_start."\t".$lnc_end."\t".$name."\t".${$gff_chr->{$name}->{"UP"}}[3]."\t".$strand."\t".${$gff_chr->{$name}->{"UP"}}[4]."\t".${$gff_chr->{$name}->{"UP"}}[5]."\tUp".$flk."K\t".$distance;
			}elsif($strand eq ${$gff_chr->{$name}->{"DOWN"}}[0] and $end>=${$gff_chr->{$name}->{"DOWN"}}[1] and $end <= ${$gff_chr->{$name}->{"DOWN"}}[2]){
				$distance=${$gff_chr->{$name}->{"DOWN"}}[2]-$end+1;
				$tag = $lncRNA_name."\t".$lnc_chr."\t".$lnc_strand."\t".$lnc_start."\t".$lnc_end."\t".$name."\t".${$gff_chr->{$name}->{"DOWN"}}[3]."\t".$strand."\t".${$gff_chr->{$name}->{"DOWN"}}[4]."\t".${$gff_chr->{$name}->{"DOWN"}}[5]."\tDown".$flk."K\t".$distance;
			}
		}
	if ($tag ne ""){print TARGRT "$tag\n"};
	}
}

sub USAGE{
	my $usage =<<"USAGE"

usage: perl $0 [options]
options:
      -p <s> output file prefix
      -m <s> mRNAgff file
      -l <s> lncgff file
      -d <s> diff lncRNA file
      -f <i> flank size, default(10000)

example: perl $0 -p human -m mrna.gff -l lncgff  -d lncRNA.diff.xls -f 10000

USAGE
}
