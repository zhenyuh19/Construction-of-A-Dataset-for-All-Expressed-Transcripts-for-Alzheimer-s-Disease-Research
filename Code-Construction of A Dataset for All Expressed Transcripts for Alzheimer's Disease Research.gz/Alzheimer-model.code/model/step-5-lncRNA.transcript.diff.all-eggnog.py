#!/python
#-*-coding:utf-8-*-

import os,sys,re
import pandas as pd

noncoding = sys.argv[1]
lncfa = sys.argv[2]
block = sys.argv[3]
noncoding_id = {}
lncfa_id = {}

with open(noncoding) as NON_FA:
	for ele in NON_FA:
		if re.search(r"^>", ele):
			faid = ele.strip("\n").split(" ")[0].split(">")[1]
			noncoding_id.setdefault(faid, "lncRNA")

with open(lncfa) as FA:
	for ele in FA:
		if re.search(r"^>", ele):
			faid = ele.strip("\n").split(" ")[0].split(">")[1]
#			print(faid)
			lncfa_id.setdefault(faid, "lncRNA")		

block_df = pd.read_csv(block, sep = "\t")
block_ID_dic = {}
for Gene_Symbol, Symble_ID in zip(block_df['Gene.Symbol'], block_df['Symble.ID']):
	block_ID_dic.setdefault(Gene_Symbol, Symble_ID)

with open(sys.argv[4]) as DIFF, open(sys.argv[5], "w") as LNC_DIFF, open(sys.argv[6], "w") as PC_DIFF, open(sys.argv[7], "w") as rest_noncoding_DIFF:
	for ele in DIFF:
		temp = ele.strip("\n").split("\t")

#		if re.search(r"Gene", ele):
		if temp[1] == "Gene":
			new_lines = temp[0] + "\t" + temp[1] + "\tSymbol.ID\t" + "\t".join(temp[2:])

			LNC_DIFF.write(new_lines + "\n")
			PC_DIFF.write(new_lines + "\n")
			rest_noncoding_DIFF.write(new_lines + "\n")
#			print(ele)
		else:
			if block_ID_dic.get(temp[1]):
				geneid = block_ID_dic.get(temp[1])
			else:
				geneid = "NA"

			new_lines = temp[0] + "\t" + temp[1] + "\t" + geneid + "\t" + "\t".join(temp[2:])

			if lncfa_id.get(temp[0]):	# 捕捉 GENCODE/novel 的 lncRNA
				LNC_DIFF.write(new_lines + "\n")
			elif noncoding_id.get(temp[0]):
				rest_noncoding_DIFF.write(new_lines + "\n")
			else:
				PC_DIFF.write(new_lines + "\n")


