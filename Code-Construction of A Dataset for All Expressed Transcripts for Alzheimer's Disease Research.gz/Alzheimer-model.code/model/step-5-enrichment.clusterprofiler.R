# author : joefish
# version: v1
# modify_date : 20191119
# document: 此脚本的 batch 移除用的 RUVg 的办法, 引入 house keeping 基因进行标准化, 为避免 house keeping 基因也是差异基因，需要进行过滤

library("optparse")
# 命令行选项
option_list = list(
	make_option(c("-f", "--DESEQ2_allgene"), type = "character", default = NULL, help = "差异结果全基因文件 [default = %default]", metavar = "character"),
	make_option(c("-u", "--DESEQ2_UP"), type = "character", default = NULL, help = "差异上调文件 [default = %default]", metavar = "character"),
	make_option(c("-d", "--DESEQ2_DOWN"), type = "character", default = NULL, help = "差异下调文件 [default = %default]", metavar = "character"),
	make_option(c("-p", "--prefix"), type = "character", default = "NULL", help = "所有输出文件的相同前缀名 [default = %default]", metavar = "character"),
	make_option(c("-o", "--outdir"), type ="character", default = ".", help = "输出目录 [default= %default]", metavar = "character"),
	make_option(c("-g", "--gene2annot"), type ="character", default = ".", help = "Gene 2 Annot [default= %default]", metavar = "character")
	

);
opt_parser = OptionParser(option_list=option_list)
opt = parse_args(opt_parser)

library(clusterProfiler)

outdir <- opt$outdir
prefix <- opt$prefix
gene2annot = load(file = opt$gene2annot)
go_anno_cmb = go_anno[c('GO','query_name','GOdesp','GO.NameSpace')]
names(go_anno_cmb) <- c('ID', 'gene_id', 'Description', 'Ontology')
#go_anno <- read.delim(gene2GO.KEGG.BiGG', header = TRUE, stringsAsFactors = FALSE)

### GO UP

up_gene_select <- read.delim(opt$DESEQ2_UP, stringsAsFactors = FALSE)$Gene
go.up.rich <- enricher(gene = up_gene_select, TERM2GENE = go_anno_cmb[c('ID', 'gene_id')], TERM2NAME = go_anno_cmb[c('ID', 'Description')], pAdjustMethod = 'BH', pvalueCutoff = 0.05, qvalueCutoff = 0.2, maxGSSize = 500)
go.up.rich.outfile = paste0(outdir, "/", prefix, ".GO.UP.xls")
write.table(go.up.rich, file = go.up.rich.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

go.up.rich.Sign <- subset(go.up.rich, go.up.rich$pvalue <= 0.05)

GO.up.cellular.component <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "cellular_component"], row.names(go.up.rich.Sign)))
GO.up.CC.df <- go.up.rich.Sign[c(GO.up.cellular.component), ]
GO.CC.up.outfile = paste0(outdir, "/", prefix, ".GO.CC.UP.xls")
write.table(GO.up.CC.df, file = GO.CC.up.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GO.up.molecular.function <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "molecular_function"], row.names(go.up.rich.Sign)))
GO.up.MF.df <- go.up.rich.Sign[c(GO.up.molecular.function), ]
GO.MF.up.outfile = paste0(outdir, "/", prefix, ".GO.MF.UP.xls")
write.table(GO.up.MF.df, file = GO.MF.up.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GO.up.biological.process <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "biological_process"], row.names(go.up.rich.Sign)))
GO.up.BP.df <- go.up.rich.Sign[c(GO.up.biological.process), ]
GO.BP.up.outfile = paste0(outdir, "/", prefix, ".GO.BP.UP.xls")
write.table(GO.up.BP.df, file = GO.BP.up.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

### GO DOWN

down_gene_select <- read.delim(opt$DESEQ2_DOWN, stringsAsFactors = FALSE)$Gene
go.down.rich <- enricher(gene = down_gene_select, TERM2GENE = go_anno_cmb[c('ID', 'gene_id')], TERM2NAME = go_anno_cmb[c('ID', 'Description')], pAdjustMethod = 'BH', pvalueCutoff = 0.05, qvalueCutoff = 0.2, maxGSSize = 500)
go.down.rich.outfile = paste0(outdir, "/", prefix, ".GO.DOWN.xls")
write.table(go.down.rich, file = go.down.rich.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

go.down.rich.Sign <- subset(go.down.rich, go.down.rich$pvalue <= 0.05)

GO.down.cellular.component <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "cellular_component"], row.names(go.down.rich.Sign)))
GO.down.CC.df <- go.down.rich.Sign[c(GO.down.cellular.component), ]
GO.CC.down.outfile = paste0(outdir, "/", prefix, ".GO.CC.DOWN.xls")
write.table(GO.down.CC.df, file = GO.CC.down.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GO.down.molecular.function <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "molecular_function"], row.names(go.down.rich.Sign)))
GO.down.MF.df <- go.down.rich.Sign[c(GO.down.molecular.function), ]
GO.MF.down.outfile = paste0(outdir, "/", prefix, ".GO.MF.DOWN.xls")
write.table(GO.down.MF.df, file = GO.MF.down.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GO.down.biological.process <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "biological_process"], row.names(go.down.rich.Sign)))
GO.down.BP.df <- go.down.rich.Sign[c(GO.down.biological.process), ]
GO.BP.down.outfile = paste0(outdir, "/", prefix, ".GO.BP.DOWN.xls")
write.table(GO.down.BP.df, file = GO.BP.down.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

### GSEA 

gene_express <- read.delim(opt$DESEQ2_allgene, stringsAsFactors = FALSE)
genelist <- gene_express$GSEA.pre.rank
names(genelist) <- gene_express$Gene
genelist <- genelist[order(genelist, decreasing = TRUE)]
gsea.rich <- GSEA(genelist, TERM2GENE = go_anno_cmb[c('ID', 'gene_id')], TERM2NAME = go_anno_cmb[c('ID', 'Description')], pvalueCutoff = 1, pAdjustMethod = 'BH', maxGSSize = 500)
gsea.rich.outfile = paste0(outdir, "/", prefix, ".GSEA.xls")
gsea.rich.Sign <- subset(gsea.rich, gsea.rich$pvalue <= 0.05)
write.table(gsea.rich.Sign, file = gsea.rich.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

gsea.rich.Sign_up <- subset(gsea.rich.Sign, gsea.rich.Sign$NES > 0)
gsea.rich.up.outfile = paste0(outdir, "/", prefix, ".GSEA.UP.xls")
write.table(gsea.rich.Sign_up, file = gsea.rich.up.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GSEA.up.cellular.component <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "cellular_component"], row.names(gsea.rich.Sign_up)))
GSEA.up.CC.df <- gsea.rich.Sign_up[c(GSEA.up.cellular.component), ]
gsea.CC.up.outfile = paste0(outdir, "/", prefix, ".GSEA.CC.UP.xls")
write.table(GSEA.up.CC.df, file = gsea.CC.up.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GSEA.up.molecular.function <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "molecular_function"], row.names(gsea.rich.Sign_up)))
GSEA.up.MF.df <- gsea.rich.Sign_up[c(GSEA.up.molecular.function), ]
gsea.MF.up.outfile = paste0(outdir, "/", prefix, ".GSEA.MF.UP.xls")
write.table(GSEA.up.MF.df, file = gsea.MF.up.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GSEA.up.biological.process <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "biological_process"], row.names(gsea.rich.Sign_up)))
GSEA.up.BP.df <- gsea.rich.Sign_up[c(GSEA.up.biological.process), ]
gsea.BP.up.outfile = paste0(outdir, "/", prefix, ".GSEA.BP.UP.xls")
write.table(GSEA.up.BP.df, file = gsea.BP.up.outfile, sep = '\t', row.names = FALSE, quote = FALSE)


gsea.rich.Sign_down <- subset(gsea.rich.Sign, gsea.rich.Sign$NES < 0)
gsea.rich.down.outfile = paste0(outdir, "/", prefix, ".GSEA.DOWN.xls")
write.table(gsea.rich.Sign_down, file = gsea.rich.down.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GSEA.down.cellular.component <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "cellular_component"], row.names(gsea.rich.Sign_down)))
GSEA.down.CC.df <- gsea.rich.Sign_down[c(GSEA.down.cellular.component), ]
gsea.CC.down.outfile = paste0(outdir, "/", prefix, ".GSEA.CC.DOWN.xls")
write.table(GSEA.down.CC.df, file = gsea.CC.down.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GSEA.down.molecular.function <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "molecular_function"], row.names(gsea.rich.Sign_down)))
GSEA.down.MF.df <- gsea.rich.Sign_down[c(GSEA.down.molecular.function), ]
gsea.MF.down.outfile = paste0(outdir, "/", prefix, ".GSEA.MF.DOWN.xls")
write.table(GSEA.down.MF.df, file = gsea.MF.down.outfile, sep = '\t', row.names = FALSE, quote = FALSE)

GSEA.down.biological.process <- c(intersect(go_anno_cmb$ID[go_anno_cmb$Ontology == "biological_process"], row.names(gsea.rich.Sign_down)))
GSEA.down.BP.df <- gsea.rich.Sign_down[c(GSEA.down.biological.process), ]
gsea.BP.down.outfile = paste0(outdir, "/", prefix, ".GSEA.BP.DOWN.xls")
write.table(GSEA.down.BP.df, file = gsea.BP.down.outfile, sep = '\t', row.names = FALSE, quote = FALSE)


