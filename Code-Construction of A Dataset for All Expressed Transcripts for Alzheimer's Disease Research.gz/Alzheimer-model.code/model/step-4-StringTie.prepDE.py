#!/python
#-*-coding:utf-8-*-

import pandas as pd
import os,re,sys

def preDE():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--remap_GTFs_dir', dest = 'remap_GTFs_dir', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest ='prefix', type = 'string', help = '')
	parser.add_option('--assembly_GTFs', dest = 'assembly_GTFs', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	remap_GTFs_dir = options.remap_GTFs_dir
	output = options.output
	prefix = options.prefix
	assembly_GTFs = options.assembly_GTFs

	if not os.path.exists(output):
		makedir_return = os.path.isdir(output) or os.makedirs(output)

	sample_lst_file = output + "/" + prefix + ".sample_lst.txt"
	with open(assembly_GTFs) as IN, open(sample_lst_file, "w") as SAMPLE_LIST:
		for ele in IN:
			basename = os.path.basename(ele).split(".")[0]
			remap_gtf = remap_GTFs_dir + "/" + basename + "/" + basename + ".StringTie.gtf"
			if not os.path.exists(remap_gtf):
				exit("{_basename} remap have a problem".format(_basename = basename))
			else:
				SAMPLE_LIST.write(basename + "\t" + remap_gtf + "\n")

	output_shell = output + "/" + prefix + ".prepDE.sh"
	with open(output_shell, "w") as PREDE:		
		shell = '''python /home/hcy/software/stringtie-2.1.4/prepDE.py \\
	-i {_sample_lst_file} \\
	-g {_output}/{_prefix}.gene_count_matrix.csv \\
	-t {_output}/{_prefix}.transcript_count_matrix.csv

'''.format(_sample_lst_file = sample_lst_file, _output = output, _prefix = prefix)

		PREDE.write(shell)

	os.system("cd {_output} && nohup sh {_output_shell} > {_output_shell}.o 2 > {_output_shell}.e &".format(_output_shell = output_shell, _output = output))



if __name__ == '__main__':
	'''
	'''	

	preDE()


