#!/python
#-*-coding:utf-8-*-

import os,sys,re

GTF = sys.argv[1]
class_code = re.compile(r"class_code \"([^\"]+)")
gene_id = re.compile(r"transcript_id \"([^\"]+)")
#cmp_ref_gene = re.compile(r"cmp_ref_gene \"([^\"]+)")	# 现有基因不需要
transcripts = {}
transcripts_exons = {}
transcripts_length = {}
with open(GTF) as IN, open(sys.argv[2], "w") as OUT:
	for ele in IN:
		if re.search(r"^#", ele):
			continue		

		temp = ele.strip("\n").split("\t")
		if temp[6] == ".":		
			continue

		if temp[2] == "transcript":
#			cmp_ref_gene_match = cmp_ref_gene.search(temp[8])
#			if cmp_ref_gene_match:
#				continue

			length = int(temp[4]) - int(temp[3])
			class_code_match = class_code.search(temp[8])
			gene_id_match = gene_id.search(temp[8])

			# 即使是 gffcompare 的注释文件里有cmp_ref_gene 信息, 但是 class_code 决定了与 cmp_ref_gene 基因的关系, 请查看 gffcompare 文档
#			if class_code_match.group(1) == "i" or class_code_match.group(1) == "u" or class_code_match.group(1) == "x":
			if class_code_match.group(1) == "o":
				transcripts.setdefault(gene_id_match.group(1), [])
				transcripts[gene_id_match.group(1)].append(ele)	
				transcripts_exons.setdefault(gene_id_match.group(1), 1)
				transcripts_length.setdefault(gene_id_match.group(1), length)

		if temp[2] == "exon":
			gene_id_match = gene_id.search(temp[8])
			if transcripts_exons.get(gene_id_match.group(1)):	
				transcripts_exons[gene_id_match.group(1)] += 1
				transcripts[gene_id_match.group(1)].append(ele)

	transcripts_identified = {}
	for tr in transcripts_exons:
		if re.search(r"MSTRG", tr):
			if transcripts_exons.get(tr) >= 2 and transcripts_length.get(tr) >= 200:	# 最开始默认就一个 exon, exon > 2个为过滤标准
				transcripts_identified.setdefault(tr, 1)
				for ele in transcripts.get(tr):
					OUT.write(ele)
					

