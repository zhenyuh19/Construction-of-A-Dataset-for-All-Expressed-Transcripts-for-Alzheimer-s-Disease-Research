#!/python
#-*-coding:utf-8-*-

import os,sys,re
import pandas as pd

DESeq2_input = sys.argv[1]
groupname = os.path.basename(DESeq2_input)
 
diff_lncRNA_up_gene = {}
diff_lncRNA_down_gene = {}
diff_codingRNA_up_gene = {}
diff_codingRNA_down_gene = {}
for par, dirs, files in os.walk(DESeq2_input):
	for subfile in files:
		inputfile = par + "/" + subfile
		if re.search(r"transcript.DESeq2.SignificanceDiff.lncRNA.xls", subfile):
			with open(inputfile) as IN:
				for dge in IN:
					temp = dge.strip("\n").split("\t")
					if temp[0] == "Gene":
						continue
			
					if float(temp[4]) > 0:
						diff_lncRNA_up_gene.setdefault(temp[0], 1)
					else:
						diff_lncRNA_down_gene.setdefault(temp[0], 1)

		if re.search(r"(transcript.*newRNA.xls)|(transcript.*pcRNA.xl)|(transcript.*restRNA.xls)", subfile):
			with open(inputfile) as IN:
				for dge in IN:
					temp = dge.strip("\n").split("\t")
					if temp[0] == "Gene":
						continue
					if float(temp[4]) > 0:
						diff_codingRNA_up_gene.setdefault(temp[0], 1)
					else:
						diff_codingRNA_down_gene.setdefault(temp[0], 1)

cis_file = sys.argv[2]
cis_uplncRNA_upcodRNA_outdir = sys.argv[3] + "/" + groupname + "/upLnc-upCoding" 
makedir_return = os.path.isdir(cis_uplncRNA_upcodRNA_outdir) or os.makedirs(cis_uplncRNA_upcodRNA_outdir)
cis_uplncRNA_upcodRNA_outfile = cis_uplncRNA_upcodRNA_outdir + "/" + groupname + ".upLncRNA-cis-upCodRNA"

cis_uplncRNA_downcodRNA_outdir = sys.argv[3] + "/" + groupname + "/upLnc-downCoding"
makedir_return = os.path.isdir(cis_uplncRNA_downcodRNA_outdir) or os.makedirs(cis_uplncRNA_downcodRNA_outdir)
cis_uplncRNA_downcodRNA_outfile = cis_uplncRNA_downcodRNA_outdir + "/" + groupname + ".upLncRNA-cis-downCodRNA"

cis_uplncRNA_codRNA_outfile = sys.argv[3] + "/" + groupname + "/" + groupname + ".upLncRNA-cis-allCodRNA"

cis_downlncRNA_upcodRNA_outdir = sys.argv[3] + "/" + groupname + "/downLnc-upCoding"
makedir_return = os.path.isdir(cis_downlncRNA_upcodRNA_outdir) or os.makedirs(cis_downlncRNA_upcodRNA_outdir)
cis_downlncRNA_upcodRNA_outfile = cis_downlncRNA_upcodRNA_outdir + "/" + groupname + ".downLncRNA-cis-upCodRNA"

cis_downlncRNA_downcodRNA_outdir = sys.argv[3] + "/" + groupname + "/downLnc-downCoding"
makedir_return = os.path.isdir(cis_downlncRNA_downcodRNA_outdir) or os.makedirs(cis_downlncRNA_downcodRNA_outdir)
cis_downlncRNA_downcodRNA_outfile = cis_downlncRNA_downcodRNA_outdir + "/" + groupname + ".downLncRNA-cis-downCodRNA"

cis_downlncRNA_codRNA_outfile = sys.argv[3] + "/" + groupname + "/" + groupname + ".downLncRNA-cis-allCodRNA"

with open(cis_file) as CIS, open(cis_uplncRNA_upcodRNA_outfile, "w") as UPLNC_UPCOD, open(cis_uplncRNA_downcodRNA_outfile, "w") as UPLNC_DOWNCOD, open(cis_downlncRNA_upcodRNA_outfile, "w") as DOWNLNC_UPCOD, open(cis_downlncRNA_downcodRNA_outfile, "w") as DOWNLNC_DOWNCOD, open(cis_uplncRNA_codRNA_outfile, "w") as UPLNC, open(cis_downlncRNA_codRNA_outfile, "w") as DOWNLNC:
	for subcis in CIS:
		temp = subcis.strip("\n").split("\t")
		if temp[0] == "lncRNA":
			UPLNC_UPCOD.write(subcis)
			UPLNC_DOWNCOD.write(subcis)
			DOWNLNC_UPCOD.write(subcis)
			DOWNLNC_DOWNCOD.write(subcis)
			UPLNC.write(subcis)
			DOWNLNC.write(subcis)

		if diff_lncRNA_up_gene.get(temp[0]) and diff_codingRNA_up_gene.get(temp[5]):
			UPLNC_UPCOD.write(subcis)
			UPLNC.write(subcis)
		if diff_lncRNA_up_gene.get(temp[0]) and diff_codingRNA_down_gene.get(temp[5]):
			UPLNC_DOWNCOD.write(subcis)
			UPLNC.write(subcis)
		if diff_lncRNA_down_gene.get(temp[0]) and diff_codingRNA_up_gene.get(temp[5]):
			DOWNLNC_UPCOD.write(subcis)
			DOWNLNC.write(subcis)
		if diff_lncRNA_down_gene.get(temp[0]) and diff_codingRNA_down_gene.get(temp[5]):
			DOWNLNC_DOWNCOD.write(subcis)
			DOWNLNC.write(subcis)

