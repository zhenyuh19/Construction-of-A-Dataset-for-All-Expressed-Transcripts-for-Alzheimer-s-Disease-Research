#!/python
#-*-coding:utf-8-*-

import pandas as pd
import os,re,sys

def REMAP_STRINGTIE():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--merged_gtf', dest = 'merged_gtf', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest ='prefix', type = 'string', help = '')
	parser.add_option('--assembly_GTFs', dest = 'assembly_GTFs', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	assemble_gtfs = options.assembly_GTFs
	output = options.output
	prefix = options.prefix
	merged_gtf = options.merged_gtf

	if not os.path.exists(output):
		makedir_return = os.path.isdir(output) or os.makedirs(output)

	def remap_gtf(out_result, bam, StringTie_merge_gtf):	
		shell = '''/home/hcy/software/stringtie-2.1.4/stringtie -e -B -p 8 -G {_StringTie_merge_gtf} -o {_out_result} {_bam}

'''.format(_StringTie_merge_gtf = StringTie_merge_gtf, _out_result = out_result, _bam = bam)

		return shell
	
	with open(assemble_gtfs) as GTFS:
		i = 0
		j = 1
		for ele in GTFS:
			if i >= 30:
				os.system("nohup sh {_output_shell} > {_output_shell}.o 2 > {_output_shell}.e &".format(_output_shell = output_shell))
				j += 1
				i = 0
			print(j)				
			output_shell = output + "/" + prefix + "_remap." + str(j) + ".sh"
			with open(output_shell, "a") as OUT:
				dirname = os.path.dirname(ele)	
				basename = os.path.basename(ele).split(".")[0]
				HISAT2_bam = dirname + "/" + basename + ".bam"
				out_dir = output + "/" + basename
				makedir_return = os.path.isdir(out_dir) or os.makedirs(out_dir) 
				out_result = output + "/" + basename + "/" + basename + ".StringTie.gtf"
				shell_return = remap_gtf(out_result = out_result, bam = HISAT2_bam, StringTie_merge_gtf = merged_gtf)
				OUT.write(shell_return)
			
			i += 1

if __name__ == '__main__':
	'''
	'''	

	REMAP_STRINGTIE()


