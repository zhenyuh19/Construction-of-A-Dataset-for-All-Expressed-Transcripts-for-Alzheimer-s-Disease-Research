#!/python
#-*-coding:utf-8-*-

import os,sys,re
import pandas as pd

DESeq2_input = sys.argv[9]
filter_gene = {}
for par, dirs, files in os.walk(DESeq2_input):
	for subfile in files:
		inputfile = par + "/" + subfile
		if re.search(r"Clinical.Info.csv$", subfile):
			basename = subfile.split(".")[0]
			case_name = basename.split("_vs_")[0]
			control_name = basename.split("_vs_")[1]

			Clinical_info_df = pd.read_csv(inputfile, sep = "\t")
			case_specimenID = Clinical_info_df['specimenID'][Clinical_info_df['sample_type'] == case_name]
			control_specimenID = Clinical_info_df['specimenID'][Clinical_info_df['sample_type'] == control_name]
			case_filter_index = len(case_specimenID) / 5	# 1/2的样本
			control_filter_index = len(control_specimenID) / 5

			stringtie_transcript_count = par + "/" + basename + ".transcript.stringtie.transcript.csv"
			stringtie_transcript_count_df = pd.read_csv(stringtie_transcript_count, sep = "\t", index_col = "transcript_id")	

			case_df = stringtie_transcript_count_df[case_specimenID]
			case_df[case_df > 0] = 1
			case_df_dict = case_df.sum(1).to_dict()
			for ele in case_df_dict:
				if case_df_dict.get(ele) >= case_filter_index:
					filter_gene.setdefault(ele, 1)

			control_df = stringtie_transcript_count_df[control_specimenID]
			control_df[control_df > 0] = 1
			control_df_dict = control_df.sum(1).to_dict()
			for ele in control_df_dict:
				if control_df_dict.get(ele) >= control_filter_index:
					filter_gene.setdefault(ele, 1)

transcript_2_genename = sys.argv[1]
stringtie_gene_2_genename = {}
with open(transcript_2_genename) as TRANSCRIPT2GENE:
	for ele in TRANSCRIPT2GENE:
		temp = ele.strip("\n").split("\t")
		stringtie_gene_2_genename.setdefault(temp[0], temp[1])

gene_record = {}
gencode_GTF = sys.argv[2]
with open(gencode_GTF) as GTF:
#	pattern = re.compile(r"ID=([^;]+).*gene_type=([^;]+)")
	pattern = re.compile(r"gene_type \"([^\"]+).*gene_name \"([^\"]+)")
	for ele in GTF:
		if re.search(r"^#",ele):
			continue
		else:
			temp = ele.strip("\n").split("\t")
			if temp[2] == "transcript":
				match = pattern.search(temp[8])	
				if match:
#					if match.group(2) == "MT-TS1":
#						print(ele)
					gene_record.setdefault(match.group(2), match.group(1))

newlncRNA_GTF = sys.argv[3]
with open(newlncRNA_GTF) as GTF:
	pattern = re.compile(r"transcript_id \"([^\"]+)")
	for ele in GTF:
		if re.search(r"^#",ele):
			continue
		else:
			temp = ele.strip("\n").split("\t")
			if temp[2] == "transcript":
				match = pattern.search(temp[8])	
				if match:
					gene_record.setdefault(match.group(1), "lncRNA")

#print(gene_record.get('MT-TS1'))

with open(sys.argv[4]) as DIFF, open(sys.argv[5], "w") as LNC_DIFF, open(sys.argv[6], "w") as PC_DIFF, open(sys.argv[7], "w") as RES_DIFF, open(sys.argv[8], "w") as NEW_GENE:
	for ele in DIFF:
		temp = ele.strip("\n").split("\t")

		if temp[0] == "Gene":
			LNC_DIFF.write(ele)
			PC_DIFF.write(ele)
			RES_DIFF.write(ele)
			NEW_GENE.write(ele)
			continue

		if not filter_gene.get(temp[0]):    # 不满足样本数要求
			continue

		if gene_record.get(temp[0]) == "lncRNA":	# 捕捉 GENCODE/novel 的 lncRNA
			LNC_DIFF.write(ele) 
		elif gene_record.get(temp[0]) == "protein_coding":	# 
			PC_DIFF.write(ele)
		elif not gene_record.get(temp[0]):
			# 没有基因名的
			if stringtie_gene_2_genename.get(temp[0]):
#				print(stringtie_gene_2_genename.get(temp[0]),"===>", gene_record.get(stringtie_gene_2_genename.get(temp[0])))
				if gene_record.get(stringtie_gene_2_genename.get(temp[0])) == "lncRNA":	
					LNC_DIFF.write(ele)
				elif gene_record.get(stringtie_gene_2_genename.get(temp[0])) == "protein_coding":
					PC_DIFF.write(ele)
				elif not gene_record.get(stringtie_gene_2_genename.get(temp[0])):
					NEW_GENE.write(ele)
				elif not re.search(r"(miRNA)|(rRNA)|(sRNA)|(vaultRNA)", gene_record.get(stringtie_gene_2_genename.get(temp[0]))):
					RES_DIFF.write(ele)
			else:
				NEW_GENE.write(ele)

#				print("新转录本 ==> ", temp[0])
#				RES_DIFF.write(ele)
		elif not re.search(r"(miRNA)|(rRNA)|(sRNA)|(vaultRNA)", gene_record.get(temp[0])):		
#		elif not re.search(r"miRNA", gene_record.get(temp[0])):
			RES_DIFF.write(ele)
		else:
			pass 




