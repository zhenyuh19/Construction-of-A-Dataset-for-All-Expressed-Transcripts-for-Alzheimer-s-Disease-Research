#!/python


import sys,os,re
import pandas as pd
import itertools  

StringTie_GTF = sys.argv[1]
GENCODE_GTF = sys.argv[2]
Predict_lncRNA_GTF = sys.argv[3]

with open(StringTie_GTF) as StringTie_GTF_HD, open(GENCODE_GTF) as GENCODE_GTF_HD, open(Predict_lncRNA_GTF) as Predict_lncRNA_GTF_HD, open(sys.argv[4],"w") as BLOCK:
	BLOCK.write("Transcript.ID\tTranscript.Length\tGene.Symbol\tgene_type\ttranscript_type\n")

	pattern_GENCODE_GTF = re.compile(r"gene_id \"([^\"]+).*transcript_id \"([^\"]+).*gene_type \"([^\"]+).*gene_name \"([^\"]+).*transcript_type \"([^\"]+)")
	pattern_StringTie_GTF1 = re.compile(r"gene_id \"([^\"]+).*transcript_id \"([^\"]+).*gene_name \"([^\"]+)")
	pattern_StringTie_GTF2 = re.compile(r"gene_id \"([^\"]+).*transcript_id \"([^\"]+)")
	pattern_Predict_lncRNA_GTF = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+)")
	
	gene_type_dic = {}
	transcript_type_dic = {}
	for ele in GENCODE_GTF_HD:
		if re.search(r"^#",ele):
			continue
		else:
			temp = ele.strip("\n").split("\t")
			if temp[2] == "transcript":
				match = pattern_GENCODE_GTF.search(temp[8])
				gene_type_dic.setdefault(match.group(4), match.group(3))
				transcript_type_dic.setdefault(match.group(2), match.group(5))
	
	lncRNA_dic = {}
	for ele in Predict_lncRNA_GTF_HD:
		if re.search(r"^#",ele):
			continue
		else:
			temp = ele.strip("\n").split("\t")
			if temp[2] == "transcript":
				match = pattern_Predict_lncRNA_GTF.search(temp[8])
				lncRNA_dic.setdefault(match.group(1), "lncRNA")
				lncRNA_dic.setdefault(match.group(2), "lncRNA")

	for ele in StringTie_GTF_HD:
		if re.search(r"^#",ele):
			continue
		else:
			temp = ele.strip("\n").split("\t")
			if temp[2] == "transcript":
				block = str(int(temp[4]) - int(temp[3]))
				match1 = pattern_StringTie_GTF1.search(temp[8])
				match2 = pattern_StringTie_GTF2.search(temp[8])
				if match1:
					gene_type = "NA"	
					if gene_type_dic.get(match1.group(3)):
						gene_type = gene_type_dic.get(match1.group(3))
					if lncRNA_dic.get(match1.group(3)):
						gene_type = lncRNA_dic.get(match1.group(3))

					transcript_type = "NA"
					if transcript_type_dic.get(match1.group(2)):
						transcript_type = transcript_type_dic.get(match1.group(2))
					if lncRNA_dic.get(match1.group(2)):
						transcript_type = lncRNA_dic.get(match1.group(2))

					BLOCK.write(match1.group(2) + "\t" + str(block) + "\t" + match1.group(3) + "\t" + gene_type + "\t" + transcript_type + "\n")
				elif match2:
					gene_type = "NA"
					if lncRNA_dic.get(match2.group(1)):
						gene_type = lncRNA_dic.get(match2.group(1))

					transcript_type = "NA"
					if lncRNA_dic.get(match2.group(2)):
						transcript_type = lncRNA_dic.get(match2.group(2))

					BLOCK.write(match2.group(2) + "\t" + str(block) + "\t" + match2.group(1) + "\t" + gene_type + "\t" + transcript_type + "\n")
				else:
					print("NONE")

