#!/python
#-*-coding:utf-8-*-

import os,sys,re

# 差异 lncRNA 的 差异 pc 靶基因, 这不能说明差异的靶基因
# 有待商榷

novel_lncRNA = sys.argv[1]
novel_lncRNA_dic = {}
with open(novel_lncRNA) as NOVEL_LNC:
	for ele in NOVEL_LNC:
		if re.search(r"^>", ele):
			isoform_name = ele.split(" ")[0].split(">")[1]
			novel_lncRNA_dic.setdefault(isoform_name, 1)

GENCODE_GTF = sys.argv[2]
STRINGTIE_compGTF = sys.argv[3]

class_code_u = {}
class_code_u_transcript_2_gene_dic = {}
transcript_2_gene_dic = {}
gene_dic = {}
pattern_0 = re.compile(r"transcript_id \"([^\"]+).*gene_name \"([^\"]+)")
pattern_1 = re.compile(r"gene_name \"([^\"]+)")
pattern_2 = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*gene_name \"([^\"]+)")
pattern_3 = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*cmp_ref_gene \"([^\"]+)")
pattern_4 = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+).*class_code \"([^\"]+)")
pattern_exon = re.compile(r"transcript_id \"([^\"]+).*gene_id \"([^\"]+)")
with open(GENCODE_GTF) as GENCODE_GTF_HD, open(STRINGTIE_compGTF) as STRINGTIE_compGTF_HD:
	for ele in GENCODE_GTF_HD:
		if re.search(r"^#", ele):
			continue

		temp = ele.strip("\n").split("\t")
		match = pattern_1.search(temp[8])
		gene_dic.setdefault(match.group(1), "")
		gene_dic[match.group(1)] += ele

		match0 = pattern_0.search(temp[8])
		if match0:
			transcript_2_gene_dic.setdefault(match0.group(1), match0.group(2))	# 转录本名 => 基因名

	stringtie_transcript_2_geneid = {}	
			# 找那些在 DESeq 里是 stringtie ID, 但在 merger gtf 中又有 GENCODE name 的基因. 这些基因在 pattern_2, pattern_3 中被匹配, 所以无法在 gene_dic 中以 gene_id 来创建键
	for ele in STRINGTIE_compGTF_HD:
		temp = ele.strip("\n").split("\t")
		match_2 = pattern_2.search(temp[8])
		match_3 = pattern_3.search(temp[8])
		match_4 = pattern_4.search(temp[8])
		match_5 = pattern_exon.search(temp[8])
		if match_2:
			# test
			if match_2.group(1) == "MSTRG.36415.3":
				print("MSTRG.36415.3 ===> 已找到 match_2 : ", match_2.group(1), match_2.group(2), match_2.group(3))

			if novel_lncRNA_dic.get(match_2.group(1)):	# 专门捕获 新的lncRNA
				gene_dic.setdefault(match_2.group(2), "")
				gene_dic[match_2.group(2)] += ele
				stringtie_transcript_2_geneid.setdefault(match_2.group(1), match_2.group(2))
				transcript_2_gene_dic.setdefault(match_2.group(1), match_2.group(2))
				continue

			if gene_dic.get(match_2.group(3)):			
				gene_dic[match_2.group(3)] += ele	
				stringtie_transcript_2_geneid.setdefault(match_2.group(2), match_2.group(3))

				transcript_2_gene_dic.setdefault(match_2.group(1), match_2.group(3))
			else:
				print("stringtie 有 gene name, 但在 GENCODE 中不存在\n")
		elif match_3:
			# test
			if match_3.group(1) == "MSTRG.36415.3":
				print("MSTRG.36415.3 ===> 已找到 match_3 :", match_3.group(1), match_3.group(2), match_3.group(3))

			if novel_lncRNA_dic.get(match_3.group(1)):	# 专门捕获 新的lncRNA
				gene_dic.setdefault(match_3.group(2), "")
				gene_dic[match_3.group(2)] += ele
				stringtie_transcript_2_geneid.setdefault(match_3.group(1), match_3.group(2))
				transcript_2_gene_dic.setdefault(match_3.group(1), match_3.group(2))
				continue

			if gene_dic.get(match_3.group(3)):
				gene_dic[match_3.group(3)] += ele
				stringtie_transcript_2_geneid.setdefault(match_3.group(2), match_3.group(3))
				transcript_2_gene_dic.setdefault(match_3.group(1), match_3.group(3))
			else:
				print("stringtie 有 gene name, 但在 GENCODE 中不存在\n")
		elif match_4:
			# test
#			if match_4.group(1) == "MSTRG.36415.3":
#				print("MSTRG.36415.3 ===> 已找到 1-match_4 : ", match_4.group(1), match_4.group(2))

			# 新的 lncRNA 包含了 u
			if novel_lncRNA_dic.get(match_4.group(1)):
				if match_4.group(3) == "u":
					class_code_u.setdefault(match_4.group(2), match_4.group(2))
				else:
					transcript_2_gene_dic.setdefault(match_4.group(1), match_4.group(2))
					stringtie_transcript_2_geneid.setdefault(match_4.group(2), match_4.group(2))

				gene_dic.setdefault(match_4.group(2), "")
				gene_dic[match_4.group(2)] += ele

#				stringtie_transcript_2_geneid.setdefault(match_4.group(2), match_4.group(2))
#				transcript_2_gene_dic.setdefault(match_4.group(1), match_4.group(2))
				continue

			# 解决 class_code "u" 问题
			# 1、u 先检验是否是 lncRNA
			# 2、不是 lncRNA
			if match_4.group(3) == "u":
				class_code_u.setdefault(match_4.group(2), match_4.group(2))					
				gene_dic.setdefault(match_4.group(2), "")
				gene_dic[match_4.group(2)] += ele
				transcript_2_gene_dic.setdefault(match_4.group(1), match_4.group(2))
			else:
				if stringtie_transcript_2_geneid.get(match_4.group(2)):
					if gene_dic.get(stringtie_transcript_2_geneid.get(match_4.group(2))):
						gene_dic[stringtie_transcript_2_geneid.get(match_4.group(2))] += ele
						transcript_2_gene_dic.setdefault(match_4.group(1), match_4.group(2))			
					else:
						print("stringtie 有 gene name, 但在 GENCODE 中不存在\n")

		elif match_5:	
			if class_code_u.get(match_5.group(2)):		# 优先判断 class code u, 以及 class code u 的 exon
				if gene_dic.get(class_code_u.get(match_5.group(2))):	
					gene_dic[class_code_u.get(match_5.group(2))] += ele
					class_code_u_transcript_2_gene_dic.setdefault(match_5.group(1), match_5.group(2))	

			elif stringtie_transcript_2_geneid.get(match_5.group(2)):	# 已经记录了 转录本信息(针对 exon, 新 lncRNA 行)
#				if match_4.group(1) == "MSTRG.36415.3":
#					print("MSTRG.36415.3 ===> 已找到 2-match_4 : ", match_4.group(1), match_4.group(2), stringtie_transcript_2_geneid.get(match_4.group(2)))

				if gene_dic.get(stringtie_transcript_2_geneid.get(match_5.group(2))):
#					if match_4.group(1) == "MSTRG.36415.3":
#						print("MSTRG.36415.3 ===> 已找到 3-match_4 : ", match_4.group(1), match_4.group(2))					

					gene_dic[stringtie_transcript_2_geneid.get(match_5.group(2))] += ele
					transcript_2_gene_dic.setdefault(match_5.group(1), match_5.group(2))
				else:
					print("stringtie 有 gene name, 但在 GENCODE 中不存在\n")
			else:
#				if match_4.group(1) == "MSTRG.36415.3":
#					print("MSTRG.36415.3 ===> 已找到 4-match_4 : ", match_4.group(1), match_4.group(2))

				gene_dic.setdefault(match_5.group(2), "")	# 已经记录了 转录本信息(针对 新 lncRNA 行, u class_code 行)
				gene_dic[match_5.group(2)] += ele
				stringtie_transcript_2_geneid.setdefault(match_5.group(2), match_5.group(2))	# 全新的转录本
				transcript_2_gene_dic.setdefault(match_5.group(1), match_5.group(2))		
		else:
			print("啥都没匹配到", ele )

################## 有待优化 ：有些预测的 lncRNA 的refname 是 pcRNA

DESeq2_resdir = sys.argv[4]
lncRNA_id = {}
pcRNA_id = {}
for par, dirs, files in os.walk(DESeq2_resdir):
	for subfile in files:
		inputfile = par + "/" + subfile
		if re.search(r"transcript.DESeq2.SignificanceDiff.lncRNA.xls$", subfile):
			with open(inputfile) as IN:
				for ele in IN:
					if re.search(r"Gene", ele):
						continue
					else:
						temp = ele.strip("\n").split("\t")
						lncRNA_id.setdefault(temp[0].strip(" "), 1)

		if re.search(r"(transcript.DESeq2.SignificanceDiff.pcRNA.xls$)|(transcript.DESeq2.SignificanceDiff.restRNA.xls$)|(transcript.DESeq2.SignificanceDiff.newRNA.xls)", subfile):
			with open(inputfile) as IN:
				for ele in IN:
					if re.search(r"Gene", ele):
						continue
					else:
						temp = ele.strip("\n").split("\t")
						pcRNA_id.setdefault(temp[0].strip(" "), 1)	

#print(lncRNA_id.get("MSTRG.24032.6"))
#print(gene_dic.get("MSTRG.36415"))

outdir = sys.argv[5]
lncRNA_gtf_out = outdir + "/Diff_lncRNA.gtf"
pcRNA_gtf_out = outdir + "/Diff_pcRNA.gtf"
with open(lncRNA_gtf_out, "w") as LNCRNA, open(pcRNA_gtf_out, "w") as PCRNA:	
	for ele in lncRNA_id:
		if class_code_u_transcript_2_gene_dic.get(ele):
			if gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)):
				LNCRNA.write(gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)))
			else:
				print("class_code_u 没有")
		elif transcript_2_gene_dic.get(ele):
#			if ele == "MSTRG.1786.2":			
#				print("MSTRG.1786.2 的基因名是 : ", transcript_2_gene_dic.get(ele))				
			if gene_dic.get(transcript_2_gene_dic.get(ele)):
				LNCRNA.write(gene_dic.get(transcript_2_gene_dic.get(ele)))
			else:
				print("{_ele}==> lncRNA 有基因名 ==> {_geneid}, 但 GTF文件没有 ====> ".format(_ele = ele, _geneid = transcript_2_gene_dic.get(ele)), gene_dic.get(transcript_2_gene_dic.get(ele)))
		else:
			print(ele, " 不存在基因名")			

	for ele in pcRNA_id:
		if class_code_u_transcript_2_gene_dic.get(ele):
			if gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)):
				PCRNA.write(gene_dic.get(class_code_u_transcript_2_gene_dic.get(ele)))
			else:
				print("class_code_u 没有")
		elif transcript_2_gene_dic.get(ele):
			if gene_dic.get(transcript_2_gene_dic.get(ele)):
				PCRNA.write(gene_dic.get(transcript_2_gene_dic.get(ele)))
			else:
				print("{_ele}==> pcRNA 有基因名 ==> {_geneid}, 但 GTF文件没有 ===> ".format(_ele = ele, _geneid = transcript_2_gene_dic.get(ele)), gene_dic.get(transcript_2_gene_dic.get(ele)))
		else:
			print(ele, " 不存在基因名")


