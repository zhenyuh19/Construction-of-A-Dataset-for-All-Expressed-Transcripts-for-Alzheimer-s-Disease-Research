#!/python
#-*-coding:utf-8-*-

def DESeq2_filter():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob
	import pandas as pd
	import numpy as np

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--DESEQ_RESULT', dest = 'DESeq2_result', type = 'string', help = '')
	parser.add_option('--outdir', dest = 'outdir', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest ='prefix', type = 'string', help = '')
	parser.add_option('--pvalue', dest = 'pvalue', type = 'string', help = '')
	parser.add_option('--foldchange', dest ='foldchange', type = 'string', help = '')	
	parser.add_option('--fdr', dest = 'fdr', type = 'string', help = '')
	parser.add_option('--gencode_gtf', dest = 'gencode_gtf', type = 'string', help = '')
	parser.add_option('--novel_lncgtf', dest = 'novel_lncgtf', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	DESeq2_result = options.DESeq2_result
	outdir = options.outdir
	prefix = options.prefix
	pvalue = options.pvalue
	foldchange = options.foldchange
	fdr = options.fdr
	gencode_gtf = options.gencode_gtf
	novel_lncgtf = options.novel_lncgtf

	if not outdir:
		makedir_return = os.path.isdir(outdir) or os.makedirs(outdir)

	noncoding_id = {}
	with open(gencode_gtf) as GTF:
		if re.search(r"transcript.DESeq2", DESeq2_result):
			pattern = re.compile(r"transcript_id \"([^\"]+).*transcript_type \"([^\"]+)")
		if re.search(r"Gene.DESeq2", DESeq2_result):
			pattern = re.compile(r"gene_type \"([^\"]+).*gene_name \"([^\"]+)")

		for ele in GTF:
			if re.search(r"^#",ele):
				continue
			else:
				temp = ele.strip("\n").split("\t")
				if temp[2] == "transcript":
					match = pattern.search(temp[8])	
					if match:
						if re.search(r"transcript.DESeq2", DESeq2_result):
							if re.search(r"(miRNA)|(rRNA)|(sRNA)|(vaultRNA)|(lncRNA)", match.group(2)):
								noncoding_id.setdefault(match.group(1), match.group(2))
						if re.search(r"Gene.DESeq2", DESeq2_result):						
							if re.search(r"(miRNA)|(rRNA)|(sRNA)|(vaultRNA)|(lncRNA)", match.group(1)):
								noncoding_id.setdefault(match.group(2), match.group(1))

	with open(novel_lncgtf) as GTF:
		pattern = re.compile(r"transcript_id \"([^\"]+)")
		for ele in GTF:
			if re.search(r"^#",ele):
				continue
			else:
				temp = ele.strip("\n").split("\t")
				if temp[2] == "transcript":
					match = pattern.search(temp[8])	
					if match:
						if re.search(r"transcript.DESeq2", DESeq2_result):
							noncoding_id.setdefault(match.group(1), "lncRNA")
						if re.search(r"Gene.DESeq2", DESeq2_result): 
							genename = ".".join(match.group(1).split(".")[:2])
							noncoding_id.setdefault(genename, "lncRNA")


	DESeq2_input = os.path.dirname(os.path.abspath(DESeq2_result))
	# 对表达的基因进行过滤 (要求 case 组至少 1/3 的样本都表达)
	ok_gene = {}
	for par, dirs, files in os.walk(DESeq2_input):
		for subfile in files:
			inputfile = par + "/" + subfile
			if re.search(r"Clinical.Info.csv$", subfile):
				basename = subfile.split(".")[0]
				case_name = basename.split("_vs_")[0]
				control_name = basename.split("_vs_")[1]

				Clinical_info_df = pd.read_csv(inputfile, sep = "\t")
				case_specimenID = Clinical_info_df['specimenID'][Clinical_info_df['sample_type'] == case_name]
				control_specimenID = Clinical_info_df['specimenID'][Clinical_info_df['sample_type'] == control_name]
				case_filter_index = len(case_specimenID) / 5	# 1/2的样本
				control_filter_index = len(control_specimenID) / 5

				if re.search(r"transcript.DESeq2", DESeq2_result):
					stringtie_transcript_count = par + "/" + basename + ".transcript.stringtie.transcript.csv"
					stringtie_count_df = pd.read_csv(stringtie_transcript_count, sep = "\t", index_col = "transcript_id")	
				if re.search(r"Gene.DESeq2", DESeq2_result):
					stringtie_gene_count = par + "/" + basename + ".Gene.stringtie.count.csv"
					stringtie_count_df = pd.read_csv(stringtie_gene_count, sep = "\t", index_col = "gene_id")

				case_df = stringtie_count_df[case_specimenID]
				case_df[case_df > 0] = 1
				case_df_dict = case_df.sum(1).to_dict()
				for ele in case_df_dict:
					if case_df_dict.get(ele) >= case_filter_index:
						ok_gene.setdefault(ele, 1)

				control_df = stringtie_count_df[control_specimenID]
				control_df[control_df > 0] = 1
				control_df_dict = control_df.sum(1).to_dict()
				for ele in control_df_dict:
					if control_df_dict.get(ele) >= control_filter_index:
						ok_gene.setdefault(ele, 1)


	DESeq2_res_df = pd.read_csv(DESeq2_result, sep = "\t", index_col = "Gene")
	DESeq2_res_df['GSEA.pre.rank'] = -np.log10(DESeq2_res_df['padj'])*DESeq2_res_df['log2FoldChange']
	DESeq2_res_ok_df = DESeq2_res_df.loc[list(ok_gene.keys())]
	DESeq2_res_ok_dic = DESeq2_res_ok_df.to_dict()
	DESeq2_res_ok_new_dic = {}	# 用来清洗基因名和生成 tranme文件, 为了后续做 RNA 分类
	DESeq2_res_ok_coding_dic = {}	# 专门用来富集的

	GSEA_pre_rank_bigger0 = {}
	for col in DESeq2_res_ok_dic:
		if col == "GSEA.pre.rank":
			for gene in DESeq2_res_ok_dic.get(col):
				if float(DESeq2_res_ok_dic.get(col).get(gene)) != 0:
					GSEA_pre_rank_bigger0.setdefault(gene, 1)

	for col in DESeq2_res_ok_dic:
		DESeq2_res_ok_new_dic.setdefault(col, {})
		DESeq2_res_ok_coding_dic.setdefault(col, {})
		for gene in DESeq2_res_ok_dic.get(col): 
			if re.search(r"\|", gene):	# 有 | 的基因处理
				new_gene = gene.split("|")[1]
				if GSEA_pre_rank_bigger0.get(gene):
					DESeq2_res_ok_new_dic[col].setdefault(gene, DESeq2_res_ok_dic.get(col).get(gene))
					if not noncoding_id.get(new_gene):
						DESeq2_res_ok_coding_dic[col].setdefault(gene, DESeq2_res_ok_dic.get(col).get(gene))

			else:
				if GSEA_pre_rank_bigger0.get(gene):
					DESeq2_res_ok_new_dic[col].setdefault(gene, DESeq2_res_ok_dic.get(col).get(gene))
					if not noncoding_id.get(gene):
						DESeq2_res_ok_coding_dic[col].setdefault(gene, DESeq2_res_ok_dic.get(col).get(gene))

	DESeq2_res_new_df = pd.DataFrame.from_dict(DESeq2_res_ok_new_dic)
	group1 = os.path.basename(DESeq2_result).split(".")[0].split("_vs_")[0]
	group2 = os.path.basename(DESeq2_result).split(".")[0].split("_vs_")[1]
	DESeq2_res_new_df = DESeq2_res_new_df[[group1, group2, 'baseMean', 'lfcSE', 'stat', 'log2FoldChange', 'pvalue', 'padj', 'GSEA.pre.rank']]
	DESeq2_res_ok_new_file = DESeq2_input + "/" + os.path.basename(DESeq2_result).split(".xls")[0] + ".preRANK.xls"
	DESeq2_res_new_df.to_csv(DESeq2_res_ok_new_file, sep = "\t", index_label = "Gene")

	DESeq2_res_ok_coding_df = pd.DataFrame.from_dict(DESeq2_res_ok_coding_dic)
	DESeq2_res_ok_coding_df = DESeq2_res_ok_coding_df[[group1, group2, 'baseMean', 'lfcSE', 'stat', 'log2FoldChange', 'pvalue', 'padj', 'GSEA.pre.rank']]
	DESeq2_res_ok_coding_file = DESeq2_input + "/" + os.path.basename(DESeq2_result).split(".xls")[0] + ".preRANK.2.enrichment.xls"	
	DESeq2_res_ok_coding_df.to_csv(DESeq2_res_ok_coding_file, sep = "\t", index_label = "Gene")

	if pvalue:
		DESeq2_res_new_filter_df = DESeq2_res_new_df[(DESeq2_res_new_df['pvalue'] <= float(pvalue)) & (abs(DESeq2_res_new_df['log2FoldChange']) >= float(foldchange))]	# 后续还要区分 pc、newRNA、restRNA
		DESeq2_res_coding_up_df = DESeq2_res_ok_coding_df[(DESeq2_res_ok_coding_df['pvalue'] <= float(pvalue)) & (DESeq2_res_ok_coding_df['log2FoldChange'] >= float(foldchange))]
		DESeq2_res_coding_down_df = DESeq2_res_ok_coding_df[(DESeq2_res_ok_coding_df['pvalue'] <= float(pvalue)) & (DESeq2_res_ok_coding_df['log2FoldChange'] <= -float(foldchange))]
	elif fdr:
		DESeq2_res_new_filter_df = DESeq2_res_new_df[(DESeq2_res_new_df['padj'] <= float(fdr)) & (abs(DESeq2_res_new_df['log2FoldChange']) >= float(foldchange))]
		DESeq2_res_coding_up_df = DESeq2_res_ok_coding_df[(DESeq2_res_ok_coding_df['padj'] <= float(fdr)) & (DESeq2_res_ok_coding_df['log2FoldChange'] >= float(foldchange))]
		DESeq2_res_coding_down_df = DESeq2_res_ok_coding_df[(DESeq2_res_ok_coding_df['padj'] <= float(fdr)) & (DESeq2_res_ok_coding_df['log2FoldChange'] <= -float(foldchange))]


	DESeq2_res_ok_new_filter_file = DESeq2_input + "/" + os.path.basename(DESeq2_result).split(".results.xls")[0] + ".SignificanceDiff.trname.xls"
	DESeq2_res_new_filter_df.to_csv(DESeq2_res_ok_new_filter_file, sep = "\t", index_label = "Gene")

	DESeq2_res_ok_coding_up_file = DESeq2_input + "/" + os.path.basename(DESeq2_result).split(".results.xls")[0] + ".SignificanceDiff.coding.UP.xls"
	DESeq2_res_coding_up_df.to_csv(DESeq2_res_ok_coding_up_file, sep = "\t", index_label = "Gene")

	DESeq2_res_ok_coding_down_file = DESeq2_input + "/" + os.path.basename(DESeq2_result).split(".results.xls")[0] + ".SignificanceDiff.coding.DOWN.xls"
	DESeq2_res_coding_down_df.to_csv(DESeq2_res_ok_coding_down_file, sep = "\t", index_label = "Gene")


if __name__ == '__main__':
	'''
	'''	

	DESeq2_filter()

