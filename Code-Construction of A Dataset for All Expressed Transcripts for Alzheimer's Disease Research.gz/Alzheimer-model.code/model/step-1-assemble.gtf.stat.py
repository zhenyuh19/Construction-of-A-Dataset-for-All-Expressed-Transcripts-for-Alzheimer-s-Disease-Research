#!/python
#-*-coding:utf-8-*-

import pandas as pd
import os,re,sys

def GTF_STAT():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--input', dest = 'input', type = 'string', help = 'the position of the COUNT data')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest ='prefix', type = 'string', help = '')
	parser.add_option('--biospecimen', dest ='biospecimen', type = 'string', help = '')	

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	input = options.input
	output = options.output
	prefix = options.prefix
	RNAseq_biospecimen = options.biospecimen

	if not os.path.exists(output):
		makedir_return = os.path.isdir(output) or os.makedirs(output)

	RNAseq_biospecimen_df = pd.read_csv(RNAseq_biospecimen)
	specimenID = RNAseq_biospecimen_df['specimenID']	
	assembly_GTF_files = output + "/" + prefix + "-assembly_GTFs.txt"
	with open(assembly_GTF_files, "w") as ASSEMBLE_GTF:
		for ele in specimenID:
			if re.search(r"Sample_", ele):			
				StringTie_gtf = input + "/" + ele.split("Sample_")[1] + "/HISAT2/" + ele.split("Sample_")[1] + ".StringTie.gtf"
			else:
				StringTie_gtf = input + "/" + ele + "/HISAT2/" + ele + ".StringTie.gtf"

			if os.path.isfile(StringTie_gtf):	
				ASSEMBLE_GTF.write(StringTie_gtf + "\n")
			else:
				print(ele, "不存在 StringTie 组装的 gtf文件\n")
		

if __name__ == '__main__':
	'''
	'''	
	GTF_STAT()


