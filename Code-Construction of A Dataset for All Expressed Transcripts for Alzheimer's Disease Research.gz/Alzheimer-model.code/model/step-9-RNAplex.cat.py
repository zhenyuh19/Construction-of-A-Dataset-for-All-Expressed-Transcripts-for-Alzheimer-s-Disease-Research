#!/python
#-*-coding:utf-8-*-

import os,re,sys,glob

inputdir = sys.argv[1]
input_alns = inputdir + "/*aln"

with open(sys.argv[2], "w") as OUT:
	pattern = re.compile(r" \(([^\)]+)")
	id_record = []
	for par, dirs, files in os.walk(inputdir):
		for aln in files:
			if re.search(r"aln", aln):	
				sample_index = os.path.basename(par).split("_")[-1]
				print(sample_index, aln)
				if int(sample_index) <= 28:
					aln_abspath = par + "/" + aln
					aln_flag = True
					with open(aln_abspath) as IN:			
						for ele in IN:
							if re.search(r"null", ele):
								aln_flag = False
								next_map_isoform = IN.next()
	
							if re.search(r">", ele):	# 必须匹配 > 行
								if not re.search(r"null", ele):
									aln_flag = True

							if aln_flag:
								match = pattern.search(ele)
								if match:
									if float(match.group(1)) <= -30:
										OUT.write(id_record[-2] + id_record[-1] + ele)
								else:
#									OUT.write(ele)
									id_record.append(ele)
							

