#!/python

import sys,re,os

# 获取所有转录本的序列信息


# 除去lncRNA, miRNA剩下的序列做 ORF 预测, 提取出 ORF 序列 > 30aa的序列


# 对序列做功能注释
