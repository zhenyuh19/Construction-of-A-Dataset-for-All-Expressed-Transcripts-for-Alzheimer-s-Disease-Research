library("optparse")
# 命令行选项
option_list = list(
	make_option(c("-i", "--DGE"), type = "character", default = NULL, help = "差异基因文件名, 有 Symbol ID 列 [default = %default]", metavar = "character"),
	make_option(c("-k", "--KEGG"), type = "character", default = NULL, help = "KEGG 结果文件前缀名 [default = %default]", metavar = "character"),
	make_option(c("-g", "--GO"), type = "character", default = NULL, help = "GO 结果文件前缀名 [default = %default]", metavar = "character"),
	make_option(c("-b", "--GO_BP"), action = "store_true", default = FALSE, help = "GO BP 富集 [default = %default]", metavar = "character"),
	make_option(c("-c", "--GO_CC"), action = "store_true", default = FALSE, help = "GO CC 富集 [default = %default]", metavar = "character"),
	make_option(c("-m", "--GO_MF"), action = "store_true", default = FALSE, help = "GO MF 富集 [default = %default]", metavar = "character"),
	make_option(c("-r", "--REACTOME"), type = "character", default = NULL, help = "REACTOME 结果文件前缀名 [default = %default]", metavar = "character"),
	make_option(c("-v", "--pvalue_cutoff"), action = "store_true", default = TRUE, help = "以 Pvalue 过滤 [default = %default]", metavar = "character"),
	make_option(c("-p", "--pvalue"), type = "numeric", default = 0.05, help = "差异 pvalue [default = %default]"),
	make_option(c("-w", "--fdr_cutoff"), action = "store_true", default = FALSE, help = "以 FDR 过滤 [default = %default]", metavar = "character"),
	make_option(c("-d", "--fdr"), type = "numeric", default = 0.05, help = "差异 fdr [default = %default]"),
	make_option(c("-o", "--outdir"), type = "character", default = ".", help = "结果文件目录 [default = %default]"),
	make_option(c("-f", "--foldchange"), type = "numeric", default = 0.378512, help = "差异倍数 cutoff [default = %default]")
);

opt_parser = OptionParser(option_list = option_list)
opt = parse_args(opt_parser)
DGE <- opt$DGE
KEGG <- opt$KEGG
GO <- opt$GO
REACTOME <- opt$REACTOME
outdir <- opt$outdir
GO_BP <- opt$GO_BP
GO_CC <- opt$GO_CC
GO_MF <- opt$GO_MF
cutoff <- opt$foldchange
pvalue_cutoff <- opt$pvalue_cutoff
pvalue <- opt$pvalue
fdr_cutoff <- opt$fdr_cutoff
fdr <- opt$fdr
cat("log2FC : ",cutoff)
cat("\n\n是否根据 pvalue 过滤 :", pvalue_cutoff, "\npvalue 过滤值:", pvalue, "\n\n是否根据 FDR 过滤 :", fdr_cutoff, "\nFDR 过滤值:", fdr)

if (file.exists(outdir)){
    setwd(file.path(outdir))
} else {
    dir.create(file.path(outdir))
    setwd(file.path(outdir))
}

library("clusterProfiler")
DGE.df <- read.csv(DGE, header = T, stringsAsFactors = F, sep = '\t')
if(pvalue_cutoff){
	cat("\n执行 pvalue 过滤")
	DGE.Symbol.UP.ID <- DGE.df$Symbol.ID[(DGE.df$Symbol.ID != "None") & (DGE.df$log2FoldChange >= cutoff) & (DGE.df$pvalue <= pvalue)]
	DGE.Symbol.DOWN.ID <- DGE.df$Symbol.ID[(DGE.df$Symbol.ID != "None") & (DGE.df$log2FoldChange <= -cutoff) & (DGE.df$pvalue <= pvalue)]
}
if(fdr_cutoff){
	cat("执行 FDR 过滤")
	DGE.Symbol.UP.ID <- DGE.df$Symbol.ID[(DGE.df$Symbol.ID != "None") & (DGE.df$log2FoldChange >= cutoff) & (DGE.df$padj <= fdr)]
	DGE.Symbol.DOWN.ID <- DGE.df$Symbol.ID[(DGE.df$Symbol.ID != "None") & (DGE.df$log2FoldChange <= -cutoff) & (DGE.df$padj <= fdr)]
}

#### SYMBOL 转 基因 ID
#eg <- bitr(x, fromType = "SYMBOL", toType = c("ENTREZID","ENSEMBL"), OrgDb = "org.Hs.eg.db")

#### ENSEMBL 转 基因 ID
#eg <- bitr(gene, fromType = "ENSEMBL", toType = c("ENTREZID", "SYMBOL"), OrgDb = org.Hs.eg.db)

if(GO_BP){
	if(length(DGE.Symbol.UP.ID) > 0){
		GO_BP.UP.enrich <- enrichGO(DGE.Symbol.UP.ID, OrgDb = "org.Hs.eg.db", ont = 'BP', pvalueCutoff = 1, pAdjustMethod = 'BH', keyType = 'ENTREZID')
		GO_BP.UP.enrich.df <- GO_BP.UP.enrich@result
		GO_BP.UP.enrich.df <- GO_BP.UP.enrich.df[GO_BP.UP.enrich.df$pvalue <= 0.05, ]
		GO_BP.UP.enrich.outfile <- paste0(outdir, "/", GO, ".UP.BP.xls")
		write.table(GO_BP.UP.enrich.df, GO_BP.UP.enrich.outfile, row.names = F, sep = "\t")
	}
	if(length(DGE.Symbol.DOWN.ID) > 0){
		GO_BP.DOWN.enrich <- enrichGO(DGE.Symbol.DOWN.ID, OrgDb = "org.Hs.eg.db", ont = 'BP', pvalueCutoff = 1, pAdjustMethod = 'BH', keyType = 'ENTREZID')
		GO_BP.DOWN.enrich.df <- GO_BP.DOWN.enrich@result
		GO_BP.DOWN.enrich.df <- GO_BP.DOWN.enrich.df[GO_BP.DOWN.enrich.df$pvalue <= 0.05, ]
		GO_BP.DOWN.enrich.outfile <- paste0(outdir, "/", GO, ".DOWN.BP.xls")
		write.table(GO_BP.DOWN.enrich.df, GO_BP.DOWN.enrich.outfile, row.names = F, sep = "\t")
	}
}

if(GO_CC){
	if(length(DGE.Symbol.UP.ID) > 0){
		GO_CC.UP.enrich <- enrichGO(DGE.Symbol.UP.ID, OrgDb = "org.Hs.eg.db", ont = 'CC', pvalueCutoff = 1, pAdjustMethod = 'BH', keyType = 'ENTREZID')
		GO_CC.UP.enrich.df <- GO_CC.UP.enrich@result
		GO_CC.UP.enrich.df <- GO_CC.UP.enrich.df[GO_CC.UP.enrich.df$pvalue <= 0.05, ]
		GO_CC.UP.enrich.outfile <- paste0(outdir, "/", GO, ".UP.CC.xls")
		write.table(GO_CC.UP.enrich.df, GO_CC.UP.enrich.outfile, row.names = F, sep = "\t")
	}
	if(length(DGE.Symbol.DOWN.ID) > 0){
		GO_CC.DOWN.enrich <- enrichGO(DGE.Symbol.DOWN.ID, OrgDb = "org.Hs.eg.db", ont = 'CC', pvalueCutoff = 1, pAdjustMethod = 'BH', keyType = 'ENTREZID')
		GO_CC.DOWN.enrich.df <- GO_CC.DOWN.enrich@result
		GO_CC.DOWN.enrich.df <- GO_CC.DOWN.enrich.df[GO_CC.DOWN.enrich.df$pvalue <= 0.05, ]
		GO_CC.DOWN.enrich.outfile <- paste0(outdir, "/", GO, ".DOWN.CC.xls")
		write.table(GO_CC.DOWN.enrich.df, GO_CC.DOWN.enrich.outfile, row.names = F, sep = "\t")
	}
}

if(GO_MF){
	if(length(DGE.Symbol.UP.ID) > 0){
		GO_MF.UP.enrich <- enrichGO(DGE.Symbol.UP.ID, OrgDb = "org.Hs.eg.db", ont = 'MF', pvalueCutoff = 1, pAdjustMethod = 'BH', keyType = 'ENTREZID')
		GO_MF.UP.enrich.df <- GO_MF.UP.enrich@result
		GO_MF.UP.enrich.df <- GO_MF.UP.enrich.df[GO_MF.UP.enrich.df$pvalue <= 0.05, ]
		GO_MF.UP.enrich.outfile <- paste0(outdir, "/", GO, ".UP.MF.xls")
		write.table(GO_MF.UP.enrich.df, GO_MF.UP.enrich.outfile, row.names = F, sep = "\t")
	}
	if(length(DGE.Symbol.DOWN.ID) > 0){
		GO_MF.DOWN.enrich <- enrichGO(DGE.Symbol.DOWN.ID, OrgDb = "org.Hs.eg.db", ont = 'MF', pvalueCutoff = 1, pAdjustMethod = 'BH', keyType = 'ENTREZID')
		GO_MF.DOWN.enrich.df <- GO_MF.DOWN.enrich@result
		GO_MF.DOWN.enrich.df <- GO_MF.DOWN.enrich.df[GO_MF.DOWN.enrich.df$pvalue <= 0.05, ]
		GO_MF.DOWN.enrich.outfile <- paste0(outdir, "/", GO, ".DOWN.MF.xls")
		write.table(GO_MF.DOWN.enrich.df, GO_MF.DOWN.enrich.outfile, row.names = F, sep = "\t")
	}
}

############# KEGG	# 暂时因为抓包问题不开放
if(length(DGE.Symbol.UP.ID) > 0){
	KEGG.UP.enrich <- enrichKEGG(DGE.Symbol.UP.ID, organism = 'hsa', keyType = 'ncbi-geneid', pvalueCutoff = 1)
	KEGG.UP.enrich.df <- KEGG.UP.enrich@result
	KEGG.UP.enrich.df <- KEGG.UP.enrich.df[KEGG.UP.enrich.df$pvalue <= 0.05, ]
	KEGG.UP.enrich.outfile <- paste0(outdir, "/", KEGG, ".UP.xls")
	write.table(KEGG.UP.enrich.df, KEGG.UP.enrich.outfile, row.names = F, sep = "\t")
}

if(length(DGE.Symbol.DOWN.ID) > 0){
	KEGG.DOWN.enrich <- enrichKEGG(DGE.Symbol.DOWN.ID, organism = 'hsa', keyType = 'ncbi-geneid', pvalueCutoff = 1)
	KEGG.DOWN.enrich.df <- KEGG.DOWN.enrich@result
	KEGG.DOWN.enrich.df <- KEGG.DOWN.enrich.df[KEGG.DOWN.enrich.df$pvalue <= 0.05, ]
	KEGG.DOWN.enrich.outfile <- paste0(outdir, "/", KEGG, ".DOWN.xls")
	write.table(KEGG.DOWN.enrich.df, KEGG.DOWN.enrich.outfile, row.names = F, sep = "\t")
}

############## Reactome
library(ReactomePA)
if(length(DGE.Symbol.UP.ID) > 0){
	Reactome.UP.enrich <- enrichPathway(gene = DGE.Symbol.UP.ID, organism = "human", pvalueCutoff = 1, readable = T)
	Reactome.UP.enrich.df <- Reactome.UP.enrich@result
	Reactome.UP.enrich.df <- Reactome.UP.enrich.df[Reactome.UP.enrich.df$pvalue <= 0.05, ]
	Reactome.UP.enrich.outfile <- paste0(outdir, "/", REACTOME, ".UP.xls")
	write.table(Reactome.UP.enrich.df, Reactome.UP.enrich.outfile, row.names = F, sep = "\t")
}

if(length(DGE.Symbol.DOWN.ID) > 0){
	Reactome.DOWN.enrich <- enrichPathway(gene = DGE.Symbol.DOWN.ID, organism = "human", pvalueCutoff = 1, readable = T)
	Reactome.DOWN.enrich.df <- Reactome.DOWN.enrich@result
	Reactome.DOWN.enrich.df <- Reactome.DOWN.enrich.df[Reactome.DOWN.enrich.df$pvalue <= 0.05, ]
	Reactome.DOWN.enrich.outfile <- paste0(outdir, "/", REACTOME, ".DOWN.xls")
	write.table(Reactome.DOWN.enrich.df, Reactome.DOWN.enrich.outfile, row.names = F, sep = "\t")
}

