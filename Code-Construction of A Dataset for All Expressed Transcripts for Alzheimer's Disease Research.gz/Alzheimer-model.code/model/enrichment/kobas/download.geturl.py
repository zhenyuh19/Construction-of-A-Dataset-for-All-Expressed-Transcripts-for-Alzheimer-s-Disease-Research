#!/python

import urllib,sys

link = sys.argv[1]
f = urllib.urlopen(link)
myfile = f.read()
print(myfile)
