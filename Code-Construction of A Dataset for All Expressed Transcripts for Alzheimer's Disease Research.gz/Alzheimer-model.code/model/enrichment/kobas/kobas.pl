#!/usr/bin/perl
use strict;
use warnings;
use File::Basename;
use Getopt::Long;
use FindBin qw($Bin $Script);
use Data::Dumper;
use Cwd qw(abs_path getcwd realpath);

my ($tax_id,$gene,$up_gene,$down_gene,$outdir,$spe);
my (%symbol2ID,%alias2ID);
my %ID2symbol;
my $type||=2;
my $gene_info||="/home/hcy/database/gene_info";

my $kobas_anno_py = "/home/hcy/software/kobas-3.0/scripts/annotate.py";
my $kobas_enrich_py = "/home/hcy/software/kobas-3.0/scripts/identify.py";

GetOptions(
          'tax=s' => \$tax_id,
          'up=s'  => \$up_gene,
          'down=s' => \$down_gene,
          'out:s'  => \$outdir,
          'spe:s' => \$spe,
          'info=s'=>\$gene_info,
          'type:s'=> \$type,
          'gene=s' => \$gene,
);

my $example_dir="/share/work2/staff/jiangdezhi/Program/RNA_seq_ref/BFC2014047/BFC2014047_Out/Differential_Analysis/mS83D_case_vs_mS83N_ctrl_edgeR";
my $usage= <<"USAGE";
           Program: $0

           Usage: perl $0 [Options]

           Options:
                  tax   :: tax id for each species
                  up    :: up regulation gene list
                  down  :: down regulation gene list
                  o     :: output directory 
                  info	:: gene_info file
                  spe	:: short name of species 
                  type	:: [1|2] 1 means single sample expression gene, 2 means differential gene,default [2]
                           -type 2 -up * -down *
                           -type 1 -gene *
                  gene	:: each sample gene list 
                    
           Example: 
           perl $0 -type 2 -up $example_dir/mS83N_vs_mS83D_Up_Expression_Table.xls -down $example_dir/mS83N_vs_mS83D_Down_Expression_Table.xls -tax 39947  -spe osa -o ./ 
           perl $0 -type 1 -gene $example_dir/mS83N_vs_mS83D_Up_Expression_Table.xls -tax 39947  -spe osa -o ./

USAGE
########################################
if (!defined $tax_id || !defined $spe || !$gene_info || !$outdir){
                                        print "$usage\n";
                                        exit;
}

#######################################
if($type eq "2"){
                if(!defined $up_gene || !defined $down_gene ){
                print "$usage\n";
                exit;
                }
}elsif($type eq "1"){
                    if(!defined $gene){
                    print "$usage\n";
                    exit;
                    }
}

#######################################  
$outdir||="KEGG_Enrichment";
mkdir $outdir unless (-d $outdir);
$outdir=abs_path($outdir);

# build a symbol-to-ID hash array.
open (GENEINFO, $gene_info=~/\.gz$/ ? "gzip -dc $gene_info|" : $gene_info) or die $!;
<GENEINFO>;
while(<GENEINFO>){

#     0  tax_id     33
#     1  GeneID     5961936
#     2  Symbol     pMF1.6
#     3  LocusTag   pMF1.6
#     4  Synonyms   pMF1.6

	chomp;
	my @infoLine = split(/\t/, $_);
	if ($infoLine[0] eq $tax_id) {

		$symbol2ID{$infoLine[2]} = $infoLine[1] ;
                $alias2ID{$infoLine[3]} = $infoLine[1] if( $infoLine[2] ne "-");
                if ( $infoLine[4] ne "-") {
                    my @alias = split /\|/,$infoLine[4];
                    map { $alias2ID{$_} = $infoLine[1] } @alias;
                }
		$ID2symbol{$infoLine[1]} = $infoLine[2];

	}
}
close GENEINFO;

#######################################################################
###Differential expression gene###
#######################################################################
my $pair;
if($type eq "2"){
	# Map the up-regulated gene symbols into their ids.
	my @up_GeneID;
	open geneSymbol, $up_gene or die;
	while(<geneSymbol>){
		chomp;
		next if $_ =~ /logFC/;
		my @symbolLine = split(/\t/, $_);
		push(@up_GeneID, $symbolLine[0]);
	}
	close geneSymbol;

	# Output the up-regulated gene ids to a disk file.
	mkdir($outdir, 0755);
	my $up_GeneSymbol = basename $up_gene;
#	$up_GeneSymbol =~ s/(.*?).Up\.xls/$1_Up/;			# 更改样本名
#	$up_GeneSymbol = split(/\./, $up_GeneSymbol)[0];
	my @temp = split(/\./, $up_GeneSymbol);
	$up_GeneSymbol = $temp[0] .".up";
#	$pair = $1;
	$pair = $temp[0];
	open(UP_IDFile, ">$outdir/$up_GeneSymbol.id") or die;
	foreach(@up_GeneID) {
		if ($symbol2ID{$_}) {
			print UP_IDFile "$symbol2ID{$_}\n";
		}elsif( $alias2ID{$_}) {
			print UP_IDFile "$alias2ID{$_}\n";
		}
	}
	close UP_IDFile;

	# Map the down-regulated gene symbols into their ids.
	my @down_GeneID;
	open geneSymbol, $down_gene or die;
	while(<geneSymbol>){
		chomp;
		next if $_ =~ /logFC/;
		my @symbolLine = split(/\t/, $_);
		push(@down_GeneID, $symbolLine[0]);
	}
	close geneSymbol;

	# Output the down-regulated gene ids to a disk file.
	my $down_GeneSymbol = basename $down_gene;
#	$down_GeneSymbol =~ s/(.*?)_Down\.xls/$1_Down/;
	@temp = split(/\./, $down_GeneSymbol);
	$down_GeneSymbol = $temp[0] .".down";		# 更改样本名
#	$down_GeneSymbol = $down_GeneSymbol . ".down";
	open(DOWN_IDFile, ">$outdir/$down_GeneSymbol.id") or die;
	foreach(@down_GeneID) {
		if ($symbol2ID{$_}) {
			print DOWN_IDFile "$symbol2ID{$_}\n";
                }elsif( $alias2ID{$_}) {
                        print DOWN_IDFile "$alias2ID{$_}\n";
                }
	}
	close DOWN_IDFile;

	# Kobas pathway enrichment analysis
	chdir $outdir;
	my $return="0";
	$return = system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python /home/hcy/software/kobas-3.0/scripts/annotate.py -i $up_GeneSymbol.id -t id:ncbigene -s $spe -o $up_GeneSymbol.annotate");
	&return_value($return,$spe,$up_GeneSymbol);##check return value ,256 : represent *.id is empty  
	print "$return => 0 等于OK\n";
	
	$return = system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python /home/hcy/software/kobas-3.0/scripts/annotate.py -i $down_GeneSymbol.id -t id:ncbigene -s $spe -o $down_GeneSymbol.annotate");
	&return_value($return,$spe,$down_GeneSymbol);
	
	#identify file adjust 
	&identify_file_adjust("$up_GeneSymbol.kegg.identify",\%ID2symbol);
	&identify_file_adjust("$up_GeneSymbol.reactome.identify",\%ID2symbol);
	&identify_file_adjust("$down_GeneSymbol.kegg.identify",\%ID2symbol);
	&identify_file_adjust("$down_GeneSymbol.reactome.identify",\%ID2symbol);

	#Barplot printing by R script
	system ("Rscript $Bin/kobas_RNA.R $up_GeneSymbol\.kegg_pathway_enrichment.tmp.xls $down_GeneSymbol\.kegg_pathway_enrichment.tmp.xls $pair");
	system ("Rscript $Bin/kobas_RNA.R $up_GeneSymbol\.reactome_pathway_enrichment.tmp.xls $down_GeneSymbol\.reactome_pathway_enrichment.tmp.xls $pair");	

	#add hyperlinks
	system("/opt/rnaseq/software/Perl-5.26/bin/perl $Bin/hyperlink.pl $up_GeneSymbol\.kegg_pathway_enrichment.tmp.xls  $up_GeneSymbol\.kegg_pathway_enrichment.xls");
	system("/opt/rnaseq/software/anaconda2/bin/python $Bin/kobas.trname.py  $up_GeneSymbol\.kegg_pathway_enrichment.tmp.xls  $up_GeneSymbol\.kegg_pathway_enrichment.csv");

	system("/opt/rnaseq/software/Perl-5.26/bin/perl $Bin/hyperlink.pl $up_GeneSymbol\.reactome_pathway_enrichment.tmp.xls $up_GeneSymbol\.reactome_pathway_enrichment.xls");
	system("/opt/rnaseq/software/anaconda2/bin/python $Bin/kobas.trname.py  $up_GeneSymbol\.reactome_pathway_enrichment.tmp.xls  $up_GeneSymbol\.reactome_pathway_enrichment.csv");

	system("/opt/rnaseq/software/Perl-5.26/bin/perl $Bin/hyperlink.pl $down_GeneSymbol\.kegg_pathway_enrichment.tmp.xls  $down_GeneSymbol\.kegg_pathway_enrichment.xls");
	system("/opt/rnaseq/software/anaconda2/bin/python $Bin/kobas.trname.py  $down_GeneSymbol\.kegg_pathway_enrichment.tmp.xls  $down_GeneSymbol\.kegg_pathway_enrichment.csv");

	system("/opt/rnaseq/software/Perl-5.26/bin/perl $Bin/hyperlink.pl $down_GeneSymbol\.reactome_pathway_enrichment.tmp.xls $down_GeneSymbol\.reactome_pathway_enrichment.xls");
	system("/opt/rnaseq/software/anaconda2/bin/python $Bin/kobas.trname.py  $down_GeneSymbol\.reactome_pathway_enrichment.tmp.xls  $down_GeneSymbol\.reactome_pathway_enrichment.csv");
	
	#download pathway map#
	&download("$outdir/$up_GeneSymbol\.kegg_pathway_enrichment.tmp.xls","$outdir/Up_KEGG_pathway_map");
#	&download("$outdir/$up_GeneSymbol\.reactome_pathway_enrichment.tmp.xl","$outdir/Up_Reactome_pathway_map");

	&download("$outdir/$down_GeneSymbol\.kegg_pathway_enrichment.tmp.xls","$outdir/Down_KEGG_pathway_map");
#	&download("$outdir/$down_GeneSymbol\.reactome_pathway_enrichment.tmp.xl","$outdir/Down_Reactome_pathway_map");
}

########################################################################
###single sample expression gene###
########################################################################
elsif($type eq "1"){
	my @GeneID;
	open geneSymbol, $gene or die;
	while(<geneSymbol>){
		chomp;
		next if $_ =~ /logFC/;
        	my @symbolLine = split(/\t/, $_);
        	push(@GeneID, $symbolLine[0]);
	}
	close geneSymbol;

	mkdir($outdir, 0755);
	my $GeneSymbol = basename $gene;
	$GeneSymbol =~ s/\.\S+?$//;
	open(IDFile, ">$outdir/$GeneSymbol.id") or die;
	foreach(@GeneID) {
        	if ($symbol2ID{$_}) {
                	print(IDFile "$symbol2ID{$_}\n");
                }elsif( $alias2ID{$_}) {
                        print IDFile "$alias2ID{$_}\n";
                }
			
	}
	close IDFile;

	# Kobas pathway enrichment analysis
	chdir($outdir);
	!system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH  && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python $kobas_anno_py -i $GeneSymbol.id -t id:ncbigene -s $spe -o $GeneSymbol.annotate") or die;
	!system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH  && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python $kobas_enrich_py -f $GeneSymbol.annotate -d K -n BH -b $spe -o $GeneSymbol.kegg.identify") or die;
	!system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH  && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python $kobas_enrich_py -f $GeneSymbol.annotate -d R -n BH -b $spe -o $GeneSymbol.reactome.identify") or die;
	
	#identify file adjust 
	&identify_file_adjust("$GeneSymbol.kegg.identify",\%ID2symbol);
	&identify_file_adjust("$GeneSymbol.reactome.identify",\%ID2symbol);
	
	#Barplot printing by R script
	system ("Rscript $Bin/kobas_RNA.R $GeneSymbol\.kegg_pathway_enrichment.tmp.xls $GeneSymbol ");
	
	#add hyperlinks
	system("/opt/rnaseq/software/Perl-5.26/bin/perl $Bin/hyperlink.pl $GeneSymbol\.kegg_pathway_enrichment.tmp.xls  $GeneSymbol\.kegg_pathway_enrichment.xls");
	system(" $Bin/kobas.trname.py  $GeneSymbol\.kegg_pathway_enrichment.tmp.xls  $GeneSymbol\.kegg_pathway_enrichment.csv");

	system("/opt/rnaseq/software/Perl-5.26/bin/perl $Bin/hyperlink.pl $GeneSymbol\.reactome_pathway_enrichment.tmp.xls $GeneSymbol\.reactome_pathway_enrichment.xls");
	system("/opt/rnaseq/software/anaconda2/bin/python $Bin/kobas.trname.py  $GeneSymbol\.reactome_pathway_enrichment.tmp.xls  $GeneSymbol\.reactome_pathway_enrichment.csv");

	#download pathway map
	&download("$outdir/$GeneSymbol\.kegg_pathway_enrichment.tmp.xls","$outdir/KEGG_pathway_map");
#	&download("$outdir/$GeneSymbol\_reactome_pathway_enrichment.tmp.xl","$outdir/Reactome_pathway_map");
	
}

#########################################################
############sub function#
#########################################################
sub download {
             my ($identify,$picdir)=@_;
             mkdir "$picdir" unless (-d $picdir );
             # !system("ssh login.local perl $Bin/download_ref.pl $identify $picdir") or die ;
             !system("/opt/rnaseq/software/Perl-5.26/bin/perl $Bin/download_ref.pl $identify $picdir") or die ;
}

sub identify_file_adjust {
             my ($infile,$ID2symbol)=@_;
             my ($prefix)=$infile=~/(\S+?)\.identify/;
             open IN ,$infile or die;
             open OUT,">$prefix\_pathway_enrichment.tmp.xls" or die;
             print OUT "Term\tDatabase\tID\tInput number\tBackground number\tP-Value\tCorrected P-Value\tInput\tHyperlink\n";
             ## pushijun
             my $first_line = <IN>;
             ## pushijun
             while(<IN>){
                chomp;
                my @gene;
                next if ($_=~/^#/ || $_=~/^---/ || $_=~/^\s*$/);
                my @arr=split /\t/;
				my @id=split /\|/,$arr[7];
                map { push @gene,$ID2symbol->{$_} } @id;
                $arr[7]=join ";",@gene;
                my $new=join "\t",@arr;
                print OUT "$new\n";
            }
            close IN;
            close OUT;
}

sub return_value{
	my ($return,$spe,$name) = @_ ;
	if ( $return == 256 ) {
		system "cp $Bin/empty.identify $name.identify";
	}elsif( $return == 0 ) {
		system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH  && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python ${kobas_enrich_py} -f $name.annotate -d K -n BH -b $spe -o $name.kegg.identify");
		system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH  && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python ${kobas_enrich_py} -f $name.annotate -d R -n BH -b $spe -o $name.reactome.identify");
		system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH  && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python ${kobas_enrich_py} -f $name.annotate -d p -n BH -b $spe -o $name.panther.identify");
		system("export PYTHONPATH=/opt/rnaseq/software/anaconda2/lib/python2.7/site-packages/:/home/hcy/software/kobas-3.0/src/:\$PYTHONPATH  && export PATH=/opt/rnaseq/software/anaconda2/bin:\$PATH && /opt/rnaseq/software/anaconda2/bin/python ${kobas_enrich_py} -f $name.annotate -d o -n BH -b $spe -o $name.omin.identify");

	}else{
		exit;
	}
}
 
