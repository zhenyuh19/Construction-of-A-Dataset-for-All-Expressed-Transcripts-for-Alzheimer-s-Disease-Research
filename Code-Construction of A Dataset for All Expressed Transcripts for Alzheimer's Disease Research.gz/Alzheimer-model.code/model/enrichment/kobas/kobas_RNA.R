rm(list=ls())
args<-commandArgs(trailingOnly = T)
if(length(args)<2) stop ("Uasge:
	1. Rscript kobas_RNA.R Up_pathway_enchriment.xls Down_pathway_enchriment.xls outfile
	2. Rscript kobas_RNA.R pathway_enrichment.xls outfile" 
)


up_down_barplot<-function(GeneCount,TERM){
        colors <- c('#4682B4','#87CEEB','#6B8E23','#A0522D','#FF8C00','#6A5ACD','#778899','#DAA520','#B22222','#FF6699')
        par(mar = c(14,12,4.1,3.1))
        mp <- barplot(
                as.numeric(GeneCount),
        #       width=1.2,
        #       legend= colnames(GeneCount),
        #       names.arg= colnames(GeneCount),
        #       space=c(0.1,rep(c(rep(0.1,nrow(GeneCount)-1),1),nrow(GeneCount)-1),rep(0.1,nrow(GeneCount)-1)),
                beside=TRUE,#是否柱状交错
        #       xlab="Percentage_of_mapped_reads(%)",
                ylab="Gene Count",
                col=rep(colors[1:3],each=nrow(GeneCount),len=nrow(GeneCount)*ncol(GeneCount)),
                axisnames=TRUE,
                axes=TRUE,
                plot=TRUE,
                xpd=FALSE,#是否超出
                ylim=c(0,max(as.numeric(GeneCount))*1.3),
        #       cex.lab=1,#伸展坐标比例
                pch=15,
        )
        legend("topleft",#"bottomright",
                legend=colnames(GeneCount),
		 cex=1,
                fill=colors[1:3],
                col=colors[1:3],
                inset = 0.01
        )
        abline(v = mp[seq(from=nrow(GeneCount),to=length(mp),by=nrow(GeneCount))]+0.5, col = "black", lwd = 1,lty=4)
        title(main=list("Kegg Pathway Analysis"));
        text(mp,as.vector(as.numeric(GeneCount)),labels = as.vector(as.numeric(GeneCount)),adj=c(0.5,-0.5), cex=0.8,xpd = TRUE)
        #print(mp)
        text(mp, par("usr")[3], labels = as.vector(TERM), srt = 35,cex=0.7, adj = c(1,1), xpd = TRUE)
        box();
        pic=dev.off()
}	
		
GO_Enrichment<-function(data,outfile){

	if ( nrow(data) < 20 ) {
			data_top20<-data.frame(data)
	}else{
			data_top20<-data.frame(data[1:20,])
	}

        pdf(paste(outfile,"_Pathway_Enrichment.pdf", sep=""),width=10,height=6)
        p<-ggplot(data = data_top20 ) + geom_point(aes(x=Term, y=Corrected.P.Value, colour=Corrected.P.Value, size=Input.number))+ coord_flip() +  scale_colour_continuous("corrected-pvalue", high="red", low="blue") + scale_size_continuous("GeneNumber") + ggtitle("Statistics of Pathway Enrichment") + xlab("Pathway Term") + ylab("Rich Factor")
        print(p)
        dev.off()

        png(paste(outfile,"_Pathway_Enrichment.png", sep=""), width=1000, height=600)
        p<-ggplot(data = data_top20 ) + geom_point(aes(x=Term, y=Corrected.P.Value, colour=Corrected.P.Value, size=Input.number))+ coord_flip() +  scale_colour_continuous("corrected-pvalue", high="red", low="blue") + scale_size_continuous("GeneNumber") + ggtitle("Statistics of Pathway Enrichment") + xlab("Pathway Term") + ylab("Rich Factor")
        print(p)
        dev.off()
}

##################up and down genes#########################
if ( length(args) == 3) {
    up<-args[1]
    down<-args[2]
    outfile<-args[3]
	
    library("ggplot2")

    data_up<-read.delim(up,head=T,sep="\t",stringsAsFactors=F)
    data_down<-read.delim(down,head=T,sep="\t",stringsAsFactors=F)
	
    if (nrow(data_up)>=20){ 
	up<-data_up[1:20,c("Term","Input.number")] 
    }else{
	length_up<-nrow(data_up)
	up<-data_up[,c("Term","Input.number")] 
	up[(length_up+1):20,c("Term")]<-NA
	up[(length_up+1):20,c("Input.number")]<-0
    }

    if (nrow(data_down)>=20){ 
	down<-data_down[1:20,c("Term","Input.number")] 
    }else{
	length_down<-nrow(data_down)
	down<-data_down[,c("Term","Input.number")] 
	down[(length_down+1):20,c("Term")]<-NA
	down[(length_down+1):20,c("Input.number")]<-0
    }

    down<-data.frame(down)
    up<-data.frame(up)

#GO enrichment barplot graph
    L_top20<-list(Up=up,Down=down)
    GeneCount<-sapply(L_top20,function(X){X$'Input.number'})
    TERM<-sapply(L_top20,function(X){X$Term})
    png("pathway_enrichment.png",pointsize=18,width=1600,height=900)
    up_down_barplot(GeneCount,TERM)
    pdf("pathway_enrichment.pdf",width=16,height=9)
    up_down_barplot(GeneCount,TERM)

#GO enrichment by ggplot2
    if ( max(as.numeric(up$'Input.number')) > 0 ) GO_Enrichment(data_up,paste(outfile,"Up",sep="_"))
    if ( max(as.numeric(down$'Input.number')) > 0 ) GO_Enrichment(data_down,paste(outfile,"Down",sep="_"))
}

#####################genes##################
if ( length(args) == 2) {
    gene<-args[1]
    outfile<-args[2]

    library("ggplot2")

    data<-read.delim(gene,head=T,sep="\t",stringsAsFactors=F)

    if (nrow(data)>=20){
        Genes<-data[1:20,c("Term","Input.number")]
    }else{
        length<-nrow(data)
        Genes<-data[,c("Term","Input.number")]
        Genes[(length+1):20,c("Term")]<-NA
        Genes[(length+1):20,c("Input.number")]<-0
    }	

#GO enrichment barplot graph
    L_top20<-list(DEG=Genes)
    GeneCount<-sapply(L_top20,function(X){X$'Input.number'})
    TERM<-sapply(L_top20,function(X){X$Term})
    png("pathway_enrichment.png",pointsize=18,width=1000,height=900)
    up_down_barplot(GeneCount,TERM)
    pdf("pathway_enrichment.pdf",width=10,height=9)
    up_down_barplot(GeneCount,TERM)

#GO enrichment by ggplot2

    if ( max(as.numeric(Genes$'Input.number')) > 0 ) GO_Enrichment(data,paste(outfile,"DEG",sep="_"))
}
