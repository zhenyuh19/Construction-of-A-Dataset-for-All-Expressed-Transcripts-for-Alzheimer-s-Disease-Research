#!/usr/bin/perl -w
use strict;
use File::Basename;
use LWP::UserAgent;
 
my ($identify,$pic)=@ARGV;

unless(@ARGV==2){
        print "\n\tUsage:\n\t\tperl $0 <adjust_identify> <pic dir>\n";
        print "\n\tExample:\n\t\tperl $0 *identify <pic dir>\n";
        exit;
}

mkdir "$pic" unless (-d "$pic");
###load pathway enrichment file
my $file=basename $identify; 
open PATHWAY,$identify or die;
<PATHWAY>;
while(<PATHWAY>){
	chomp;
	my ($ko,$url)=(split /\t/,$_)[2,8];
	my $content;
	system("python /home/haoyang/huangcy/pipeline/GO_KEGG/KEGG/NCBI/up_down_gene/download.geturl.py $url > $content\n");
	print $content;
	print "Can not find ko number: $ko\n" unless ($content);

	######extract content of map position###############
	my ($lines)=$content =~/(<map name="mapdata">.*?<\/map>)/s;
	my @lines=split /\n/,$lines;
	my $head=html_head($ko);
	my $body=html_body($ko);

	###produce map.html###
	open HTML,">$pic/$ko.html" or die;
	print HTML "$head\n<body>\n";
	foreach (@lines){
		if ($_ eq "<map name=\"mapdata\">"){
			print HTML "<map name=\"$ko\">\n";
		}else{
			$_=~s/href=\"/href=\"http:\/\/www.genome.jp/;
			print HTML "$_\n";
		}
	}
	###html body###
	print HTML "$body";
	###download png###
	if($content=~/<img src=\"(.+png)\"/){
    		system("wget -q http://www.genome.jp/$1 -P $pic");
	}
}
close HTML;
close PATHWAY;

##########################
my @png=<$pic/*.png>;
foreach my $png (@png){
	my $tmp=basename $png;
	if($tmp =~ /_/){
		$tmp=~s/_\S+?\.png/\.png/;
		system "mv $png $pic/$tmp";
	}
}

######sub function######
sub html_head{
	my $ko=shift;
	my $head="<html>
<head>
<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">
<title>$ko</title>
<style type=\"text/css\">
<!--
area {cursor: pointer;}
-->
</style>
<script type=\"text/javascript\">
<!--
function showInfo(info) {
        obj = document.getElementById(\"result\");
        obj.innerHTML = \"<div style=\'cursor: pointer; position: absolute; right: 5px; color: #000;\' onclick=\'javascript: document.getElementById(\\\"result\\\").style.display = \\\"none\\\";\' title=\'close\'>X</div>\" + info;
        obj.style.top = document.body.scrollTop;
        obj.style.left = document.body.scrollLeft;
        obj.style.display = \"\";
}
//->
</script>
</head>";
	return($head);
}

sub html_body {
	my $ko=shift;
	my $body="<img src=\'./$ko.png\' usemap=\'#$ko\' />
<div id=\'result\' style=\'position: absolute; width: 50%; border: 1px solid #000; background-color: #fff; filter: alpha(opacity=95); opacity: 0.95; font-size: 12px; padding-right: 20px; display: none;\' onmouseover=\"javascript: this.style.filter = \'alpha(opacity=100)\'; this.style.opacity = 1;\" onmouseout=\"javascript: this.style.filter = \'alpha(opacity=95)\'; this.style.opacity = 0.95;\"></div>
</body></html>";
	return($body);
}


