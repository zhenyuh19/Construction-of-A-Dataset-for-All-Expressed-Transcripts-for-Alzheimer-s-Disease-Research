#!/python

import os,sys,re
import pandas as pd

basename = os.path.basename(sys.argv[1]).split(".tmp.xls")[0] + ".csv"
#df = pd.read_table(sys.argv[1])
df = pd.read_csv(sys.argv[1], sep = "\t")
df2 = df[df["P-Value"] <= 0.05]
df2 = df2.to_csv(sys.argv[2], index = False)
