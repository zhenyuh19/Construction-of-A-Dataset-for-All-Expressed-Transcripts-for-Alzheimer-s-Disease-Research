#!/usr/bin/perl -w

=pod
description: get go class and alias from gene ontology in obo format
author: Zhang Fangxian, zhangfx@
created date: 20101118
modified date: 20101203
=cut

use strict;
use Getopt::Long;

my ($go, $prefix, $help);

GetOptions("go:s" => \$go, "prefix:s" => \$prefix, "help|?" => \$help);
$prefix ||= "go";

if (!$go || $help) {
	die << "USAGE";
description: get go class and alias from gene ontology in obo format
usage: perl $0 [options]
options:
	-go <file> *    gene ontology in obo format
	-prefix <file>  directory with prefix for output files, default is "go"

	-help|?         help information
e.g.:
	perl $0 -go go.obo -prefix go
USAGE
}

my (%gos, %obsoletes, %parents, %alias, $id, $name, $namespace);

&showLog("read file: $go");
open IN, "< $go" or die;
while (<IN>) {
	chomp;
	if (/^id:\s+(.*)/) {
		$id = $1;
	} elsif (/^name:\s+(.*)/) {
		$name = $1;
	} elsif (/^namespace:\s+(.*)/) {
		$namespace = $1;
		$gos{$id} = [$name, $namespace];
	} elsif (/is_obsolete: true/) {		# GO ID 被废弃 
		$obsoletes{$id} = 1;
	} elsif (/^alt_id:\s+(.*)/) {		# 别名
		push @{$alias{$id}}, $1,
	} elsif (/^is_a:\s+([^\s]+)/) {		# 父节点信息
		push @{$parents{$id}}, $1;
	} elsif (/^relationship:.*(GO:[\d]+)/) {
		push @{$parents{$id}}, $1;
	}
}
close IN;

### GO ID 另一个 GO ID别名
&showLog("write file: $prefix.alias");    
open ALIAS, "> $prefix.alias" or die $!;
for $id (keys %alias) {
	next if (exists $obsoletes{$id});
	print ALIAS join("\t", $id, @{$alias{$id}}) . "\n";
}
close ALIAS;

&showLog("write file: $prefix.class");
open CLASS, "> $prefix.class" or die $!;
for $id (keys %gos) {
	next if (exists $obsoletes{$id});		# 废弃ID 不作考虑
	my %temps;
	&getParents($id, \%parents, \%temps);	# 找到二级父节点，仅次于 BP,MF.CC的节点
	for (keys %temps) {
#		next if ($id eq $_);
		print CLASS join("\t", $gos{$id}[1], $gos{$_}[0], $id, $gos{$id}[0]) . "\n"; # first class, second class, term id, term
	}
}
close CLASS;

&showLog("done");

exit 0;

sub showLog {
	my ($info) = @_;
	my @times = localtime; # sec, min, hour, day, month, year
	print STDERR sprintf("[%d-%02d-%02d %02d:%02d:%02d] %s\n", $times[5] + 1900, $times[4] + 1, $times[3], $times[2], $times[1], $times[0], $info);
}

sub getParents {
	my ($id, $parents, $results) = @_;
	if (!exists $parents->{$id}) {
		return;
	}
	for (@{$parents->{$id}}) {
		if (!exists $parents->{$_}) {
			$results->{$id} = 1;
		} else {
			&getParents($_, $parents, $results);
		}
	}
}
