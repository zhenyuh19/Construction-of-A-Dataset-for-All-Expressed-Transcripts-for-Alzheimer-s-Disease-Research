#!/bin/env python
#-*-coding:utf-8-*-
# convert output xls files of topGO.pl to HTML page

import sys


# HTML template
HTMLtemp = """<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Gene ontology terms for {NAME}</title>
<style type="text/css">
<!--
body {{background-color: #fff;}}
table {{background-color: #000; border-collapse: collapse; border: solid #000 1px;}}
tr {{background-color: #fff;}}
th, td {{border: solid #000 1px;}}
a.applet {{cursor: pointer; line-height: 50px; text-decoration: underline;}}
-->
th {{color:white;font-size:16px;background-color:#0766c6}}
</style>

<script type="text/javascript">
<!--
function reSize2() {{
    try {{
        parent.document.getElementsByTagName("iframe")[0].style.height = document.body.scrollHeight + 10;
        parent.parent.document.getElementsByTagName("iframe")[0].style.height = parent.document.body.scrollHeight;
                        
        }} catch(e) {{}}

}}

var preRow = null;
var preColor = null;

function colorRow(trObj) {{
    if (preRow != null) {{
        preRow.style.backgroundColor = preColor;
            
    }}
        preRow = trObj;
        preColor = trObj.style.backgroundColor;
        trObj.style.backgroundColor = "#fafad2";

}}

function diffColor(tables) {{
    var color = ["#fff", "#efefef"];

    for (var i = 0; i < tables.length; i++) {{
        var trObj = tables[i].getElementsByTagName("tr");

        for (var j = 1; j < trObj.length; j++) {{
            trObj[j].style.backgroundColor = color[j % color.length];                                                        
        }} 

    }}

}}

function showPer(tableObj) {{
    trObj = tableObj.getElementsByTagName("tr");
    if (trObj.length < 2) {{
        return;
    }}
    var sum1 = trObj[0].cells[2].innerHTML.replace(/^.*\(([\d]+)\).*$/, "$1");
    var sum2 = 0;
    if (trObj[0].cells.length > 4) {{
        sum2 = trObj[0].cells[3].innerHTML.replace(/^.*\(([\d]+)\).*$/, "$1");                                            
    }}
    trObj[0].cells[2].innerHTML = "DEGs with pathway annotation (" + sum1 + ")";
    if (trObj[0].cells.length > 4) {{
        trObj[0].cells[3].innerHTML = "All genes with pathway annotation (" + sum2 + ")";                                                            
    }}
    for (var i = 1; i < trObj.length; i++) {{
        trObj[i].cells[2].innerHTML += " (" + (Math.round(trObj[i].cells[2].innerHTML * 10000 / sum1) / 100) + "%)";
        if (trObj[0].cells.length > 4) {{
            trObj[i].cells[3].innerHTML += " (" + (Math.round(trObj[i].cells[3].innerHTML * 10000 / sum2) / 100) + "%)";                                                                                                       
        }}                                                                       
    }}
}}

window.onload = function() {{
    setTimeout("reSize2()", 1);
}}
</script>

</head>

<body>
<center><h2>Gene ontology terms for <!--NAME--></h2></center><hr color="#B2B2B2"/>
<center>
    <img src='./{PNG}.png' usemap='#goPathImage'>
</center>
<center>
    <a href='./{PNG}.pdf' target='_blank' title='click to view pdf'>
    <b>Top 10 significant GO term(click me)</b></a>
</center>
<br /><br />
<HR style="FILTER: alpha(opacity=100,finishopacity=0,style=3)" width="90%" color=#987cb9 SIZE=3>
<a name="table" /><center><h3>Result Table</h3></center><p />
<center>
    <p>Terms from the Component Ontology with p-value as good or better than 0.05</p>
</center>
<table border="2" align="center" width="98%">
    <tr>
        <th align="center">GO ID</th>
        <th align="center">Gene Ontology term</th>
        <th align="center">Cluster frequency</th>
        <th align="center">Genome frequency of use</th>
        <th align="center">P-value</th>
        <th align="center">Corrected P-value</th>
    </tr>
    {SUMMARY}
</table>
<br />
<br />
<table align="center" border="2" width="98%">
    <tr>
        <th align="center">GO ID</th>
        <th align="center">Gene Ontology term</th>
        <th align="center">Genes annotated to the term</th>
    </tr>
    {TABLE}
</table>
</body>
</html>
"""


# parse topGO output file
def geneTable(infile):
    gene_summary_list = []
    gene_table_list = []
    i = 1
#    top_500 = 0
    with open(infile) as handle:
        for f in handle:
#            if top_500 > 500:
#                break
#            top_500 += 1

            if f.startswith("GO_ID"):
                continue
            fl = f.split('\t')
            gene_summary_temp = """<tr>
                    <td>
                        <a target="infowin" 
                        href="http://amigo.geneontology.org/amigo/term/{GOID}" 
                        title='jump to GO website'>{GOID}</a>
                    </td>
                    <td>
                        {GOterm}<a href='#term{idx}' 
                        onclick='javascript: colorRow(document.getElementsByTagName("table")[1].rows[{idx}]);' 
                        title='click to view genes'>(view genes)</a>
                    </td>
                    <td>{anno_diff} out of {diff} genes, {diff_freq:.2g}</td>
                    <td>{anno_genome} out of {genome} genes,{genome_freq:.2g}</td>
                    <td>{pvalue}</td><td>{fdr}</td>
                    </tr>\n""" 
            gene_summary = gene_summary_temp.format(GOID=fl[0], GOterm=fl[1], 
                        idx=i, anno_diff=fl[4], diff=fl[5], 
                        diff_freq=float(fl[4])/int(fl[5]), 
                        anno_genome=fl[2], genome=fl[3], 
                        genome_freq=float(fl[2])/int(fl[3]), 
                        pvalue=fl[-3], fdr=fl[-2])
            gene_table_temp = """<tr>
                    <td>{GOID}</td>
                    <td><a target="infowin" 
                        href="http://amigo.geneontology.org/amigo/term/{GOID}" 
                        name=term{idx} title='jump to GO website'>{GOterm}</a>
                    </td>
                    <td>{genes}</td>
                    </tr>\n""" 
            gene_table = gene_table_temp.format(GOID=fl[0], idx=i, GOterm=fl[1], 
                                genes=fl[-1].replace(' ', ', '))
            gene_summary_list.append(gene_summary)
            gene_table_list.append(gene_table)
            i += 1
    return gene_summary_list, gene_table_list


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print "USAGE: python topGO2HTML.py BP.xls BP.html"
        sys.exit(0)

    gene_summary_list, gene_table_list = geneTable(sys.argv[1])
    HTMLtemp = HTMLtemp.format(PNG=sys.argv[1].split('.')[-2].split('/')[-1],
                    SUMMARY=''.join(gene_summary_list),
                    TABLE=''.join(gene_table_list),
                    NAME=sys.argv[2].split('.')[-2].split('/')[-1])

    with open(sys.argv[2], 'w') as handle:
        handle.write(HTMLtemp)

