#!/usr/bin/perl -w

=pod
description: draw GO
created date: 20091020
modified date: 20100318, 20010204, 20100123, 20091208, 20091021
=cut

use Getopt::Long;
use File::Basename qw(dirname);
use Cwd 'abs_path';

my ($indir, $outdir, $diff, $goClass, $go, $up_down, $help, $col, $genetype);
GetOptions(
	"go:s" => \$go,
	"goclass:s" => \$goClass, 
	"diff:s" => \$diff,
	"indir:s" => \$indir, 
	"outdir:s" => \$outdir, 
	"col:i" =>\$col,  
	"up_down:s" =>\$up_down,
	"genetype:s" =>\$genetype,
	"help|?" => \$help
);
$goClass0 = "/home/haoyang/huangcy/database/blast2go/Gene.Ontology/go-basic.class";
$goClass ||= $goClass0;
$indir ||= "./";
$outdir ||= $indir;
$col ||= 5;  # 差异基因上下调标志列
system("mkdir -p $outdir") if (!-d $outdir);

sub usage {
	print STDERR << "USAGE";
description: draw GO
usage: perl $0 [options]
options:
	*-indir: directory of *GeneDiffExpressionSignificance.xls
	*-diff: diff compares for wego, separated by comma ","
	*-go:s path and prefix of go files (*.[CFP])
	 -goclass: go.class file, default is "$goClass0"
	 -outdir: outdir with prefix of ouput file, default is [indir]
	 -col:if diff is edgeR choice 6 ;default 5
	 -help|?: help information
e.g.:
	perl $0 -go goannot/species -goclass go.class -diff a-VS-b
USAGE
}

if (!defined $diff || !defined $go || defined $help) {
	&usage();
	exit 1;
}

# check input files
@diffs = split /,/, $diff;
$exit = 0;

for my $diffs (@diffs) {
       	if (!-f "$indir/${diffs}.GeneDiffExpSign.DESeq2.$genetype.$up_down.xls") {
               	warn ("file $indir/${diffs}.GeneDiffExpSign.DESeq2.$genetype.$up_down.xls not exists!\n");$exit = 1;
	}
}

exit 1 if ($exit == 1);
my $output = "$outdir/".(join ".", @diffs);

#glist
my %cfp = &getCFP($go);
for my $diffs (@diffs) {
	open OUT, "> $outdir/$diffs.$genetype.$up_down.glist" or die $!;				# 差异基因和GO ID 的关系
	open OUT1, "> $outdir/$diffs.$genetype.$up_down.glist2" or die $!;				# 差异基因、上下调、GO ID 的关系
	open IN, "< $indir/${diffs}.GeneDiffExpSign.DESeq2.$genetype.$up_down.xls";
	<IN>;
	while (<IN>) {
		my @tabs = split /\t/;
		if (exists $cfp{$tabs[0]}) {							# 基因有 GO id
#            my $col = @tabs - 3;								# 基因上下调标签位置，不同差异结果文件这里要修改, 1gene在倒数第三列
#			my $col = 5;
			print OUT "$tabs[0]\t".(join "\t", @{$cfp{$tabs[0]}})."\n";
			print OUT1 "$tabs[0]\t$tabs[$col]\t".(join "\t", @{$cfp{$tabs[0]}})."\n";	# $tabs[$col] = up/down 的列位置
		}
	}
	close IN;close OUT;
	close OUT1;
}

# main
my @inputs = map {"$_.glist2"} @diffs;	# 获取每个差异结果的 基因 => GO 关系表
@items = ();
%stats = ();
for $input (@inputs) {
#	$input = abs_path($input);
	$item = &getItemName($input);
	push @items, $item;
	%had = ();
	open IN, "<$outdir/$input" || die $!;
	while (<IN>) {
		chomp;
		next if (/^\s*$/);
		@tabs = split /[\t;]/, $_;
		$gene = shift @tabs;
		my $updown=shift @tabs;
		$stats{"total"}{$item}++;
		for $go (@tabs) {
			next if ($go eq "-");
			next if ($go =~ /^\s*$/);
			next if ($go !~ /^GO:/);
			$go = (split /\//, $go)[0];
			next if (exists $had{$go}{$gene});
			push @{$gos{$go}{$item}}, "$gene,$updown";
			#print "$gene,$updown\n";
			$had{$go}{$gene} = 1;
		}
	}
	close IN;
}

open CLASS, "< $goClass" || die $!;
while (<CLASS>) {
	chomp;
	next if (/^$/);
	@tabs = split /\t/, $_;
	if (exists $gos{$tabs[2]}) {
		for $item (@items) {
			next if (!exists $gos{$tabs[2]}{$item});
			for $g (@{$gos{$tabs[2]}{$item}}) {
				if (!exists $classes{$tabs[0]}{$tabs[1]}{$item}) {
					push @{$classes{$tabs[0]}{$tabs[1]}{$item}}, $g;
				} else {
					push @{$classes{$tabs[0]}{$tabs[1]}{$item}}, $g if (index("," . (join ",", @{$classes{$tabs[0]}{$tabs[1]}{$item}}) . ",", ",$g,") == -1);
				}
			}
		}
	}
}
close CLASS;

$data = ["", ["GO Class", "Percent of genes", "Number of genes"], [], []]; # [图名, [x 轴名称 y 轴名称], [[图例, 颜色], ...],[[x 坐标名称, 数据], ...]]

@colors = ("#cd5c5c","#159C77","#AA0000","#1111EE", "#5BCE0F", "#FFC125", "#00008B", "#008B8B", "#B8860B", "#A9A9A9", "#006400", "#BDB76B", "#8B008B", "#556B2F", "#FF8C00", "#8B0000", "#E9967A");

for $i (0 .. $#items) {
	push @{$data->[2]}, [$items[$i], $colors[$i]];
}

## 统计每个过程的二级信息
open OUT, "> $output.$genetype.$up_down.GO2gene.xls" || die $!;
print OUT "Ontology\tClass";
for $item (@items) {
	print OUT "\tNumbers_of_$item\tUp-Regulation($item)\tDown-Regulation($item)\tGenes_of_$item";
}
print OUT "\n";


for $class (sort keys %classes) {
	for $class2 (sort keys %{$classes{$class}}) {
		print OUT "$class\t$class2";
		$goStat{$class}++;
		$goStat{"total"}++;
		push @{$data2}, $class2;
		for (@items) {
			$count = (exists $classes{$class}{$class2}{$_})? @{$classes{$class}{$class2}{$_}} : 0;
			my $up =grep { $_=~ /UP/i }  @{$classes{$class}{$class2}{$_}};
			my $down=$count - $up;
			if ($count == 0) {
				print OUT "\t0\t-\t";
			} else {
				print OUT "\t$count\t$up\t$down\t" . (join ";", @{$classes{$class}{$class2}{$_}});
			}
			push @{$data2}, "$up,$down";
			if (!exists $stats{"max"}{$_} || $stats{"max"}{$_} < $count) {
				$stats{"max"}{$_} = $count;
			}
		}
		print OUT "\n";
		push @{$data->[3]}, $data2;
		undef($data2);
	}
}

close OUT;

$width = 1500;
$height = 800;
my $svgheight=$height+40;

%margins = ("t" => 60, "r" => 100, "b" => 300, "l" => 100);

$code = '<?xml version="1.0" encoding="utf-8" ?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"><svg width="' . 1600 . '" height="' . $svgheight . '" version="1.1" xmlns="http://www.w3.org/2000/svg">'."\n";

# 添加一个大矩形，使得背景颜色为白色
$code .= '<rect x="0" y="0" width="1600" height="' . $svgheight . '" style="fill: white; stroke-width:0;" />\n';

# 边框
#$code .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" style="fill: none; stroke: #000; stroke-width: 2;" />';

# x-y 坐标???
$code .= '<line x1="' . $margins{"l"} . '" y1="' . ($height - $margins{"b"}) . '" x2="' . ($width - $margins{"r"}) . '" y2="' . ($height - $margins{"b"}) . '" style="stroke: #000; stroke-width: 2;" />'."\n";

$code .= '<line x1="' . $margins{"l"} . '" y1="' . ($height - $margins{"b"}) . '" x2="' . $margins{"l"} . '" y2="' . $margins{"t"} . '" style="stroke: #000; stroke-width: 2;" />\n';
$code .= '<line x1="' . ($width - $margins{"r"}) . '" y1="' . ($height - $margins{"b"}) . '" x2="' . ($width - $margins{"r"}) . '" y2="' . $margins{"t"} . '" style="stroke: #000; stroke-width: 2;" />'."\n";

# y 轴名???
$code .= '<text x="' . ($margins{"l"} - 50) . '" y="' . (($height - $margins{"b"} + $margins{"t"}) / 2) . '" style="fill: #000; font-size:18px;text-anchor: middle;" transform="rotate(-90, ' . ($margins{"l"} - 50) . ', ' . (($height - $margins{"b"} + $margins{"t"}) / 2) . ')">' . $data->[1]->[1] . '</text>'."\n";
$code .= '<text x="' . ($width - $margins{"r"} + 140) . '" y="' . (($height - $margins{"b"} + $margins{"t"}) / 2) . '" style="fill: #000; font-size:18px;text-anchor: middle;" transform="rotate(-90, ' . ($width - $margins{"r"} + 140) . ', ' . (($height - $margins{"b"} + $margins{"t"}) / 2) . ')">' . $data->[1]->[2] . '</text>'."\n";

# y 轴坐标线
for ($i = 0; $i < 4; $i++) {
	if ($i>0){
	$code .= '<line x1="' . ($margins{"l"} - 4) . '" y1="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" x2="' . ($width - $margins{"r"}) . '" y2="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" style="stroke: #B2B2B2; stroke-width: 1;" />'."\n";
	}else{
		$code .= '<line x1="' . ($margins{"l"} - 4) . '" y1="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" x2="' . ($width - $margins{"r"}) . '" y2="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" style="stroke: #000; stroke-width: 2;" />'."\n";
	}
	$code .= '<text x="' . ($margins{"l"} - 8) . '" y="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" style="text-anchor: end; dominant-baseline: central;">' . 0.1 * 10 ** $i . '</text>'."\n";
	
	$code .= '<line x1="' . ($width - $margins{"r"}) . '" y1="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" x2="' . ($width - $margins{"r"} + 4) . '" y2="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" style="stroke: #000; stroke-width: 2;" />'."\n";
	@text = ();
	for $j (0 .. $#items) {
		if ($i == 0) {
			push @text, '<tspan style="fill: ' . $colors[$j] . ';">0</tspan>';
		} else {
			push @text, '<tspan style="fill: ' . $colors[$j] . ';">' . int($stats{"total"}{$items[$j]} / 10 ** (3 - $i)) . '</tspan>';
		}
	}
	$text = join "<tspan>,</tspan>", @text;
	$code .= '<text x="' . (($width - $margins{"r"}) + 8) . '" y="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (3 - $i) / 3) . '" style="text-anchor: start; dominant-baseline: central;">' . $text . '</text>'."\n";
}

$itemWidth = ($width - $margins{"l"} - $margins{"r"}) / ($#{$data->[3]} + 1);
$angel = 70;

# x 轴分???
$left = $margins{"l"};
for $class (sort keys %classes) {
	$x1 = $left;
	$y1 = $height - $margins{"b"};
	$x2 = $x1 - 250 * cos($angel * 3.14159 / 180) / sin($angel * 3.14159 / 180);
	$y2 = $y1 + 300;
	$x3 = $x2 + ($goStat{$class} - 0) * $itemWidth;
	$y3 = $y2;
	$x4 = $x1 + ($goStat{$class} - 0) * $itemWidth;
	$y4 = $y1;
	$code .= "<path d=\"M$x1 $y1 L$x2 $y2 L$x3 $y3 L$x4 $y4\" style=\"stroke: #000; stroke-width: 1; fill-opacity: 0;\" />"."\n";
	$code .= "<text x='" . ($x2 + $x3) / 2 . "' y='" . ($y2 + 20) . "' style='text-anchor: middle;'>" . $class . "</text>"."\n";
	$left = $x4;
}

# 数据
$text = "";
for ($i = 0; $i <= $#{$data->[3]}; $i++) {
	for ($j = 1; $j <= $#{$data->[3]->[$i]}; $j++) {
		$data->[3]->[$i]->[$j] = 0.001 if (!$data->[3]->[$i]->[$j]);
		my $up= 0.001 if (!$data->[3]->[$i]->[$j]);
		my $down= 0.001 if (!$data->[3]->[$i]->[$j]);
		($up,$down)=split /,/,$data->[3]->[$i]->[$j];
		$up=0.001 if ($up==0);
		$down=0.001 if ($down==0);
		my $total=$up+$down;
		my $myHeight=($height - $margins{"t"} - $margins{"b"}) * (3 + log($total / $stats{"total"}{$items[$j - 1]}) / log(10)) / 3;
		my $yTotal=($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) * (-(log($total / $stats{"total"}{$items[$j - 1]}) / log(10)) / 3));
		my $myHeight_up=$myHeight*$up/$total;
		my $myHeight_down=$myHeight*$down/$total;
		my $y_up=$yTotal;
		my $y_down=$yTotal+$myHeight_up;
		$myHeight_down = 0 if ($myHeight_down < 0);
		$myHeight_up = 0 if ($myHeight_up < 0);
		#print "$up,$down\t$total--$myHeight--$yTotal\t$y_up\t$myHeight_up\t$y_down\t$myHeight_down\n";
		$code .= '<rect x="' . ($margins{"l"} + $itemWidth * ($i + ($j + 0.0) / ($#{$data->[3]->[$i]} + 2))) . '" y="' . $y_up . '" width="' . $itemWidth / ($#{$data->[3]->[$i]} + 2) . '" height="' . $myHeight_up . '" style="fill: #DA434E;stroke:#222;stroke-width:0;" />'."\n";
		
		$code .= '<rect x="' . ($margins{"l"} + $itemWidth * ($i + ($j + 0.0) / ($#{$data->[3]->[$i]} + 2))) . '" y="' .$y_down. '" width="' . $itemWidth / ($#{$data->[3]->[$i]} + 2) . '" height="' . $myHeight_down . '" style="fill: #4FB0AC;stroke:#222;stroke-width:0;" />'."\n";
		
	}
	$code .= '<text x="' . ($margins{"l"} + $itemWidth * ($i + 0.5)) . '" y="' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) + 10) . '" style="fill: #000; text-anchor: end;" transform="rotate(' . -$angel . ', ' . ($margins{"l"} + $itemWidth * ($i + 0.5)) . ', ' . ($margins{"t"} + ($height - $margins{"t"} - $margins{"b"}) + 10) . ')">' . $data->[3]->[$i]->[0] . '</text>'."\n";
}
$code .= $text;

# 图例
for ($i = 0; $i <= $#{$data->[2]}; $i++) {
	$code .= '<text x="' . ($width - $margins{"r"} + 10) . '" y="' . ($margins{"t"} + $height * 2/ 3  + 20 * $i) . '" style="fill: #000;font-size:13px;text-anchor: start;">' . $data->[2]->[$i]->[0] . '</text>'."\n";
	$code .='<rect width="10" height="10" x="' . ($width - $margins{"r"}+10) . '" y="' . ($margins{"t"} + $height * 2/ 3 + 20 * $i+10) . '" style="fill:#DA434E;" />'."\n".'<text x="' . ($width - $margins{"r"} + 25) . '" y="' . ($margins{"t"} + $height * 2/ 3 + 20 + 20 * $i) . '" style="fill: #000; text-anchor: start;">Up-Regulation</text>'."\n";
	$code .='<rect width="10" height="10" x="' . ($width - $margins{"r"}+10) . '" y="' . ($margins{"t"} + $height * 2/3 + 20 * $i+30) . '" style="fill:#4FB0AC;" />'."\n".'<text x="' . ($width - $margins{"r"} + 25) . '" y="' . ($margins{"t"} + $height * 2/3 + 40 + 20 * $i) . '" style="fill: #000; text-anchor: start;">Down-Regulation</text>'."\n";
}

# 图名
$code .= '<text x="' . $width / 2 . '" y="' . ($height - 20) . '" style="fill: #000; text-anchor: middle;">' . $data->[0] . '</text>'."\n";

$code .= '</svg>';

# 输出
open SVG, "> $output.$genetype.$up_down.goclass.svg" || die $!;
print SVG $code;
close SVG;
#system("java -Djava.awt.headless=true  -jar /home/hcy/software/batik-1.10/batik-rasterizer-1.10.jar -m image/png $output.goclass.svg ");
system("convert $output.$genetype.$up_down.goclass.svg  $output.$genetype.$up_down.goclass.png");
exit 0;

sub getItemName {
	my ($str) = @_;
	$str = (split /[\/\\]/, $str)[-1];
	$str = (split /\./, $str)[0];
	return $str;
}
sub getGlist {
	my ($diff, $glist) = @_;
	my %info;
	open OUT, ">$glist" or die $!;
	open IN, "<$diff" or die $!;
	chomp (my $header = <IN>);
	my ($c, $f ,$p) = &getCFP_index($header);
	while (<IN>) {
		chomp;
		my @tabs = split /\t/;
		my @annots = ();
		for my $index ($c, $f, $p) {
			if ($tabs[$index] ne "-") {
				my @gos = split /;/, $tabs[$index];
				foreach my $go (@gos) {$go =~ s/^(GO:\d+)\/\/.*/$1/};
				@annots = (@annots, @gos);
			}
		}
		print OUT "$tabs[0]\t".(join "\t", @annots)."\n" if (@annots != 0);
	}
	close IN;
	close OUT;
}
sub getCFP {
	my $goprefix = shift;
	my %cfp;
	foreach my $cfp ("C", "F", "P") {
		open IN, "< $goprefix.$cfp" or die "$goprefix.$cfp not existed!\n";
		while (<IN>) {
			my @tabs = split /\t+/;
			push @{$cfp{$tabs[1]}}, $tabs[4];
		}
		close IN;
	}
	return %cfp;
}
