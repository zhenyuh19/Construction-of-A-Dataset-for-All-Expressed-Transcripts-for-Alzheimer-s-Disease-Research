#!/usr/bin/perl
# Date: 2015-7-23

use strict;
use warnings;
use Getopt::Long;
use FindBin '$Bin';


my ($outdir,$diff,$pvalue,$firstSigNode,$nodeSizes,$help,$go,$genelist);

GetOptions(
	"GO:s" => \$go,
	"genelist:s" => \$genelist, 
	"outdir:s" => \$outdir, 
	"pvalue:s"=>  \$pvalue,
	"firstSigNode:s"=>\$firstSigNode,
	"nodeSizes:s"=>\$nodeSizes,
	"help|?" => \$help
);
$outdir ||= "./topGO_out";
$pvalue ||= 0.01;
$firstSigNode ||= 10;
$nodeSizes ||=5;

system("mkdir -p $outdir") if (!-d $outdir);

sub usage {
 print STDERR << "USAGE";
 description: topGO GO enrichment analysis
 usage: perl $0 [options]
 options: (*) required
    *-go: gene2go mapping file path
    *-genelist: input gene list to analysis. e.g.: xx/Result/GeneDiffExpression/DESeq/A-VS-B.
                glist
    -pvalue: p-value cut-off, default is 0.01
    -firstSigNode: default is 10
    -nodeSizes: prune the GO hierarchy from the terms which have less than [-nodeSizes] 
                annotated genes, default is 5
    -outdir: dir of the result, default is [./topGO_out]
    -help|?: help information 
 e.g.:
    perl $0 -outdir topGO_out -firstSigNode 10 -pvalue 0.01 -nodeSizes 5 -go gene2go.mapping -genelist diff_gene.glist
USAGE
    exit 1;
}

usage if (!defined $go || !defined $genelist  || defined $help);

if (defined $go && defined $genelist) {
	$genelist =~ s/\.glist//g;
	system("/home/hcy/software/R_conda/bin/Rscript $Bin/topGO.R $genelist.glist $outdir $go classic $nodeSizes $pvalue");
}

#$genelist =~ s/\.glist//g;
$genelist =~ /([\w-]*?$)/;

# add topGO2HTML.py path
foreach my $term (qw / BP CC MF /){
#	system("head -n 501 $outdir/$1_$term.xls > $outdir/$1_$term.xls2 && mv $outdir/$1_$term.xls2 $outdir/$1_$term.xls");
	system("python2 $Bin/topGO2HTML.py $outdir/$1_$term.xls $outdir/$1_$term.html");
#	system("python2 $Bin/topGO2HTML.py $outdir/$genelist\_$term.xls $outdir/$genelist\_$term.html");
}
