#!/usr/bin/perl
#author : liangq@1gene.com.cn 20150723
use strict;

my ($indir,$outdir)=@ARGV;

if(!defined $indir){
	die "perl $0 <dir of Go*html> <outdir>\nauthor:liangq\@1gene.com.cn";	
	exit 1;
}

`mkdir -p -m 755` unless (-d "$outdir");
chdir $outdir;
&genView();

sub genView{
open VIEW, "> GOView.html" or die $!;
print VIEW << "HTMLCODE";
<html>
<head>
<title>GOView</title>
<script type="text/javascript">
<!--
window.onload = function() {
        document.getElementsByTagName("frameset")[0].cols = (document.getElementsByTagName("frame")[0].scrollWidth + 10) + ", *"; document.getElementsByTagName("frame")[0].style.borderRight = "1px solid #000";
}
//-->
</script>
</head>
<frameset marginwidth="0" cols="180, *" border="1" frameborder="1" marginheight="0"><frame marginwidth="0" name="list" border="1" marginheight="0" src="GOViewList.html" /> <frame marginwidth="0" name="result" border="1" marginheight="0" /></frameset>
</html>
HTMLCODE
        close VIEW;

        open LIST, "> GOViewList.html" or die $!;
        print LIST << "HTMLCODE";
<html>
<head>
<title>GOViewList</title>
</head>
<body>
<br><input name=exe type="hidden" size=20 value="regedit"><br>
HTMLCODE
for my $filename (glob("./*_*.html")) {
                my $basename = $filename;
		#print "$filename\n";
                $basename =~ s/\.html$//;
                print LIST "<a target=\"result\" href=\"$filename\">$basename</a><br />\n";
	}
	print LIST "</body>\n</html>\n";
	close LIST;
}


