#!/usr/bin/Rscript
# GO enrichment analysis script for topGO.

args = commandArgs(T)
if (length(args) != 6){
  print("USAGE: Rscript topGO.R gene.txt outputdir GOmapping algorithm")
  print('algorithm: one of classic, elim, weight, weight01, lea or parentchild.')
  print('output file prefix is xxx of xxx.Sig.xls.')
  quit(save='no')
}

input = args[1]
outprefix = args[2]
gomapping = args[3]
algo = args[4]
nodeSizes = args[5]
pvalue = args[6]

# load package silently.
suppressPackageStartupMessages(library(topGO))
suppressPackageStartupMessages(library(multtest))

# 极为个性化，自己制作背景文库
# read gene to GO id mapping file.
geneID2GO <- readMappings(gomapping, sep = "\t", IDsep = ",")
geneNames <- names(geneID2GO)
diffGenes <- read.table(input, stringsAsFactor = FALSE, header = T)
diffGenes = diffGenes[,1]
geneList <- factor(as.integer(geneNames %in% diffGenes))
names(geneList) <- geneNames

clustersize = table(geneList)[2]        # GO annotated genes in cluster
allgenesize = length(geneNames)         # Go annotated genes

fileprefix = strsplit(basename(input)[1], split=".", fixed=T)[[1]][1]     # file name prefix

# creat GOdata and analysis
for (term in c('CC', 'BP', 'MF')) {
	GOdata <- new("topGOdata", ontology = term, allGenes = geneList, annotationFun = annFUN.gene2GO, gene2GO = geneID2GO, nodeSize = nodeSizes)

	#GOdata
	resultFisher <- runTest(GOdata, algorithm = algo, statistic = "fisher")

	sigNum = sum(resultFisher@score <= pvalue)

	# In case of a small amount significant result, output all result instead
	if (sigNum <= 5) {
    	sprintf('%s low enrichment.', term)
    	sigNum = length(resultFisher@score)
	}

	Res <- GenTable(GOdata, classicFisher = resultFisher, ranksOf = "classicFisher", topNodes = sigNum, numChar = 200)

	# FDR calculating.
	raw_p = as.numeric(Res[,6])
	res = mt.rawp2adjp(raw_p,"BH")
	FDR = res$adjp[order(res$index), ]
	FDR[is.na(FDR)] = 0

	# diffGenes belong to GO.ID 
	GenesInTerms = ''
	for (i in Res$GO.ID) {
    	gogenes = intersect(genesInTerm(GOdata, i)[[1]], diffGenes)
    	gogenes = paste(gogenes, collapse = " ")
    	GenesInTerms = rbind(GenesInTerms, gogenes)
    }
	GenesInTerms = GenesInTerms[-1,]

	# Combine FDR and GenesInTerms to result.
	#print(names(Res))
	Res = cbind(Res[,1:3], rep(allgenesize, sigNum), Res[,4], rep(clustersize, sigNum), Res[,6])
	allRes = cbind(Res, FDR[,2], GenesInTerms)
	names(allRes) = c('GO_ID', 'GOTerm', 'GeneNumInTerm', 'AllAnnotatedGenes', 'GeneNumInTerm(sample)', 'InputGeneNum', 'pvalue', 'FDR', 'gene_list')

	xls_result = paste(outprefix, "/", fileprefix, "_", term, '.xls', sep = "")		# 输出文件名
	write.table(allRes, file = xls_result, sep = "\t", row.names = FALSE, col.names = TRUE, quote = FALSE)

	pdf_result = paste(outprefix, "/", fileprefix, "_", term, '.pdf', sep = "")
	pdf(pdf_result)
	showSigOfNodes(GOdata, score(resultFisher), firstSigNodes = 10, useInfo = 'all')
	dev.off()

	png_result = paste(outprefix, "/", fileprefix, "_", term, '.png', sep = "")
	png(png_result, width = 960, height = 900)
	showSigOfNodes(GOdata, score(resultFisher), firstSigNodes = 10, useInfo = 'all')
	dev.off()
}

