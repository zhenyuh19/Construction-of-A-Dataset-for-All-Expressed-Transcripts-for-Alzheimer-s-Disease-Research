library("optparse")
# 命令行选项
option_list = list(
	make_option(c("-w", "--all.DEG"), type = "character", default = NULL, help = "差异分析结果文件名 [default = %default]", metavar = "character"),
	make_option(c("-v", "--GSEA.gmt"), type = "character", default = NULL, help = "GSEA gmt 文件目录 [default = %default]", metavar = "character"),
	make_option(c("-a", "--GSEA.C1"), action = "store_true", default = FALSE, help = "C1 富集 [default = %default]"),
	make_option(c("-b", "--GSEA.C2"), action = "store_true", default = FALSE, help = "C2 富集 [default = %default]"),
	make_option(c("-c", "--GSEA.C3"), action = "store_true", default = FALSE, help = "C3 富集 [default = %default]"),
	make_option(c("-d", "--GSEA.C4"), action = "store_true", default = FALSE, help = "C4 富集 [default = %default]"),
	make_option(c("-e", "--GSEA.C5"), action = "store_true", default = FALSE, help = "C5 富集 [default = %default]"),
	make_option(c("-f", "--GSEA.C6"), action = "store_true", default = FALSE, help = "C6 富集 [default = %default]"),
	make_option(c("-g", "--GSEA.h"), action = "store_true", default = FALSE, help = "hallmarker 富集 [default = %default]"),
	make_option(c("-z", "--GSEA.all"), action = "store_true", default = FALSE, help = "GSEA all 富集 [default = %default]"),
	make_option(c("-l", "--GO_BP"), action = "store_true", default = TRUE, help = "GO BP 富集 [default = %default]"),
	make_option(c("-m", "--GO_CC"), action = "store_true", default = FALSE, help = "GO CC 富集 [default = %default]"),
	make_option(c("-n", "--GO_MF"), action = "store_true", default = FALSE, help = "GO MF 富集 [default = %default]"),
	make_option(c("-p", "--KEGG"), action = "store_true", default = FALSE, help = "KEGG 富集 [default = %default]"),
	make_option(c("-r", "--REACTOME"), action = "store_true", default = FALSE, help = "REACTOME 富集 [default = %default]"),
	make_option(c("-j", "--SMPDB"), action = "store_true", default = FALSE, help = "SMPDB 富集 [default = %default]"),
	make_option(c("-x", "--by.pvalue"), action = "store_true", default = TRUE, help = "以 Pvalue 过滤 [default = %default]"),
	make_option(c("-s", "--pvalue.cutoff"), type = "numeric", default = 0.05, help = "差异 pvalue [default = %default]"),
	make_option(c("-y", "--by.fdr"), action = "store_true", default = FALSE, help = "以 FDR 过滤 [default = %default]"),
	make_option(c("-t", "--fdr.cutoff"), type = "numeric", default = 0.05, help = "差异 fdr [default = %default]"),
	make_option(c("-k", "--prefix"), type = "character", default = "NULL", help = "所有输出文件的相同前缀名 [default = %default]", metavar = "character"),
	make_option(c("-o", "--outdir"), type ="character", default = ".", help = "输出目录 [default= %default]", metavar = "character")
);
opt_parser = OptionParser(option_list = option_list)
opt = parse_args(opt_parser)

library(clusterProfiler)
library(GSEABase)
library(fgsea)

GSEA.opt.list <- list(c1 = opt$GSEA.C1, c2 = opt$GSEA.C2, c3 = opt$GSEA.C3, c4 = opt$GSEA.C4, c5 = opt$GSEA.C5, c6 = opt$GSEA.C6, hallmarker = opt$GSEA.h, GO_BP = opt$GO_BP, GO_CC = opt$GO_CC, GO_MF = opt$GO_MF, KEGG = opt$KEGG, REACTOME = opt$REACTOME, SMPDB = opt$SMPDB)

### 1 创建目录
outdir <- opt$outdir
if(!dir.exists(outdir)){
	dir.create(outdir)
}

### 2 读取差异结果
DEG <- read.table(opt$all.DEG, sep = "\t", row.names = 1, header = T)
DEG <- DEG[DEG$pvalue <= 0.05, ]
geneList.logfc <- DEG$log2FoldChange
names(geneList.logfc) <- rownames(DEG)
geneList.logfc <- sort(geneList.logfc, decreasing = T)

### 3 
for(key in names(GSEA.opt.list)){
	if(GSEA.opt.list[[key]]){
		if(key == "GO_BP"){
			GSEA.gmt <- paste0(opt$GSEA.gmt, "/c5")
			gmts <- list.files(GSEA.gmt, pattern = 'bp.v7.1.symbols.gmt')	# 正则匹配文件, 抓 gmt 文件
		} else if (key == "GO_CC") {
			GSEA.gmt <- paste0(opt$GSEA.gmt, "/c5")
			gmts <- list.files(GSEA.gmt, pattern = 'cc.v7.1.symbols.gmt')
		} else if (key == "GO_MF") {
			GSEA.gmt <- paste0(opt$GSEA.gmt, "/c5")
			gmts <- list.files(GSEA.gmt, pattern = 'mf.v7.1.symbols.gmt')
		} else if (key == "KEGG") {
			GSEA.gmt <- paste0(opt$GSEA.gmt, "/c2")
			gmts <- list.files(GSEA.gmt, pattern = 'kegg.v7.1.symbols.gmt')
		} else if (key == "REACTOME") {
			GSEA.gmt <- paste0(opt$GSEA.gmt, "/c2")		
			gmts <- list.files(GSEA.gmt, pattern = 'reactome.v7.1.symbols.gmt')
		} else if (key == "SMPDB") {
			GSEA.gmt <- paste0(opt$GSEA.gmt, "/SMPDB")
			gmts <- list.files(GSEA.gmt, pattern = '.gmt')
		}else{
			GSEA.gmt <- paste0(opt$GSEA.gmt, "/", key)
			gmts <- list.files(GSEA.gmt, pattern = 'all.v7.1.symbols.gmt')
		}

		gsea_results <- lapply(gmts, function(gmtfile){	# 对 gmts 中每个元素执行 function, function 如下
			gmtfile.abspath <- paste0(normalizePath(GSEA.gmt), "/", gmtfile)
			geneset <- read.gmt(gmtfile.abspath)
			egmt <- GSEA(geneList.logfc, TERM2GENE = geneset, verbose = TRUE, pvalueCutoff = 1)	# S4 对象
			basename <- basename(gmtfile)

			# 指定通路作图	
			#	png("test.GSEA.png")
			#	plotEnrichment(pathwaysH[["HALLMARK_ESTROGEN_RESPONSE_EARLY"]], ranks)
			#	gseaplot(egmt,'HALLMARK_KRAS_SIGNALING_DN')
			#	dev.off()

			egmt@result$Description <- paste0('http://www.gsea-msigdb.org/gsea/msigdb/cards/', egmt@result$Description)
			egmt@result <- egmt@result[order(egmt@result$NES, decreasing = TRUE), ]
			outfile <- paste0(outdir, "/", basename, ".xls")
			write.table(egmt@result[egmt@result$pvalue <= 0.05, ], file = outfile, row.names = FALSE, sep = "\t")	# 输出 pvalue <= 0.05
			}
		)
	}
}
