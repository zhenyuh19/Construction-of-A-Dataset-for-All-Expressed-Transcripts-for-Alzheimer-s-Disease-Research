#!/python

import os,sys,re
gene_record = {}
gencode_GTF = sys.argv[1]
with open(gencode_GTF) as GTF:
	pattern = re.compile(r"gene_type=([^;]+).*gene_name=([^;]+)")
	for ele in GTF:
		if re.search(r"^#",ele):
			continue
		else:
			temp = ele.strip("\n").split("\t")
			if temp[2] == "gene":
				match = pattern.search(temp[8])	
				if match:
					gene_record.setdefault(match.group(2), match.group(1))

newlncRNA_GTF = sys.argv[2]
with open(newlncRNA_GTF) as GTF:
	pattern = re.compile(r"Name=([^;]+)")
	for ele in GTF:
		if re.search(r"^#",ele):
			continue
		else:
			temp = ele.strip("\n").split("\t")
			if temp[2] == "gene":
				match = pattern.search(temp[8])	
				if match:
					gene_record.setdefault(match.group(1), "lncRNA")

with open(sys.argv[3]) as DIFF, open(sys.argv[4], "w") as LNC_DIFF, open(sys.argv[5], "w") as PC_DIFF, open(sys.argv[6], "w") as RES_DIFF:
	for ele in DIFF:
		temp = ele.strip("\n").split("\t")
		if temp[0] == "Gene":
			LNC_DIFF.write(ele)
			PC_DIFF.write(ele)
			RES_DIFF.write(ele)
			continue

		if re.search(r"\|", temp[0]):
			genename = temp[0].split("|")[1]
		else:
			genename = temp[0]

		if gene_record.get(genename) == "lncRNA":
			LNC_DIFF.write(ele) 
			
		elif gene_record.get(genename) == "protein_coding":
			PC_DIFF.write(ele)
				
		else:
			RES_DIFF.write(ele) 

