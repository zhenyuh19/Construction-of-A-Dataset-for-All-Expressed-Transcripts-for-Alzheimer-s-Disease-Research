/home/hcy/software/blast-2.2.9/blastall \
	-a 4 \
	-b 10 \
	-m 8 \
	-p blastx \
	-e 1e-5 \
	-d /home/hcy/database/Uniprot/uniprot_sprot.blastall.db/uniprot_sprot \
	-i long_noncoding_RNAs_1.fa \
	-o sw_blast.txt
