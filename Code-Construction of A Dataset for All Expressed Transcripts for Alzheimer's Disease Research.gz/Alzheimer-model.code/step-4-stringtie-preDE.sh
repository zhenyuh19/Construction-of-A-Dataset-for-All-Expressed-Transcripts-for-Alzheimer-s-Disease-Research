mkdir step-4-StringTie.prepDE
python model/step-4-StringTie.prepDE.py \
	--remap_GTFs_dir /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-3-remap.GTF.2.ballgown \
	--assembly_GTFs /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-1-DPFC-lncRNA-assembly_GTFs/DPFC-lncRNA-assembly_GTFs.txt \
	--output /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-4-StringTie.prepDE \
	--prefix DPFC-StringTie
