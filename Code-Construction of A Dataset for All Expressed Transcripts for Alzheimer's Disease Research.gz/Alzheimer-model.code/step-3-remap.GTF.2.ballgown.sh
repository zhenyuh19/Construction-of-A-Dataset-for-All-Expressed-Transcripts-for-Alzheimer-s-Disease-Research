python model/step-3-remap.GTF.2.ballgown.py \
	--merged_gtf /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.gtf \
	--output /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-3-remap.GTF.2.ballgown \
	--assembly_GTFs /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/Analysis/Dorsolateral.Prefrontal.Cortex/step-1-DPFC-lncRNA-assembly_GTFs/DPFC-lncRNA-assembly_GTFs.txt \
	--prefix DPFC-remap.GTF
