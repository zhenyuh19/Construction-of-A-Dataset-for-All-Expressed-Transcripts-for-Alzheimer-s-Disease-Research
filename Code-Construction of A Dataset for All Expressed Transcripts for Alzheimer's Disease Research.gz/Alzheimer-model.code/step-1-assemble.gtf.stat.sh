python3 model/step-1-assemble.gtf.stat.py \
	--input /home/hcy/database/Synapse/ROSMAP/Gene.Expression/Gene.Expression_bulk.brain.RNA.seq/ROSMAP.RNAseq.fastq.files/Dorsolateral.Prefrontal.Cortex \
	--output ./step-1-DPFC-lncRNA-assembly_GTFs \
	--prefix DPFC-lncRNA \
	--biospecimen RNAseq+miRNA.RNAseq.biospecimen.csv
