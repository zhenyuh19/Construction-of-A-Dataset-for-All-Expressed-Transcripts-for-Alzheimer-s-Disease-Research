# 不要一开始就转换名字，先用新的转录本名, 提取新转录本名与就转录本关系, 分析出转录本的类型(pc 还是lnc, 还是其他)

python model/step-5-StringTie.Count-DESeq2.py \
	--stringtie_gene_count /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-4-StringTie.prepDE/DPFC-StringTie.gene_count_matrix.csv \
	--stringtie_transcript_count /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-4-StringTie.prepDE/DPFC-StringTie.transcript_count_matrix.csv \
	--biospecimen /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/RNAseq+miRNA.RNAseq.biospecimen.csv \
	--metadata /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/RNAseq+miRNA.RNAseq.metadata.csv \
	--ROSMAP_Clinical /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/RNAseq+miRNA.ROSMAP_Clinical_2019-05_v3.csv \
	--output /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-5-DESeq2


