# StringTie-merge : 合并的 gtf 用于提取表达量 ( 里面含有 lnc 和 coding mRNA)
echo === start at : `date` ===

/home/hcy/software/stringtie-2.1.4/stringtie --merge -p 8 -G  /home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.primary_assembly.annotation.gtf -o step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.gtf step-1-DPFC-lncRNA-assembly_GTFs/DPFC-lncRNA-assembly_GTFs.txt

/home/hcy/software/cufflinks-2.2.1.Linux_x86_64/gffread -w step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.fa -g /home/hcy/database/Homo_sapiens/GeneCode/v34/GRCh38.primary_assembly.genome.fa step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.gtf

#perl /home/hcy/pipeline/lncRNA/lncRNA_4.00/modules/Assemble/gtf2gff3.pl --cfg /home/hcy/pipeline/lncRNA/lncRNA_4.00/modules/Assemble/gtf2gff3.cfg step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.gtf > step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.gff

echo === finish at : `date` ===
