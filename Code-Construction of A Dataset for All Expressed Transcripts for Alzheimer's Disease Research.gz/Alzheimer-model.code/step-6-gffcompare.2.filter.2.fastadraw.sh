echo === start at : `date` ===

# 要查看精确度和敏感度, 每个样本最好单独分开看, 不要用 DPFC-stringtie_merged.gtf, 这里只是为了方便获取 class_code 才一次性跑这个
mkdir step-6-gffcompare.2.filter.2.fastadraw
/home/hcy/software/gffcompare/gffcompare -r /home/hcy/database/Homo_sapiens/GeneCode/v34/gencode.v34.primary_assembly.annotation.gtf -G -o step-6-gffcompare.2.filter.2.fastadraw/merged  step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.gtf

# step-6 : 给合并的GTF 过滤(>= 2 exon + 200bp + 非参考基因 + class mode[新的 lncRNA 不能与 exon 区有重叠, 只能选 I U X])，提取出符合 lncRNA(gffcompare 的结果中 i u x 的mode有 cmp_ref_gene基因不用去管) 的转录本，用于预测
python model/gtf.filter.py step-6-gffcompare.2.filter.2.fastadraw/merged.annotated.gtf  step-6-gffcompare.2.filter.2.fastadraw/novel.candidate.lncRNA.gtf
#perl /home/hcy/pipeline/lncRNA/lncRNA_4.00/modules/Assemble/gtf2gff3.pl --cfg /home/hcy/pipeline/lncRNA/lncRNA_4.00/modules/Assemble/gtf2gff3.cfg novel.candidate.lncRNA.gtf > novel.candidate.lncRNA.gff

# step-7 : 提取出符合 lncRNA 转录本的序列
/home/hcy/software/cufflinks-2.2.1.Linux_x86_64/gffread -w step-6-gffcompare.2.filter.2.fastadraw/novel.candidate.lncRNA.fa -g /home/hcy/database/Homo_sapiens/GeneCode/v34/GRCh38.primary_assembly.genome.fa step-6-gffcompare.2.filter.2.fastadraw/novel.candidate.lncRNA.gtf

# 提取 转录本对应的基因名 从 merged.annotated.gtf 中提取
python model/step-6-annotated.transcript-2-genename.py step-6-gffcompare.2.filter.2.fastadraw/merged.annotated.gtf step-8-venn.2.lncRNAstat/novel.lnc.fa step-6-gffcompare.2.filter.2.fastadraw/merged.annotated.transcript-2-genename.txt

echo === end at : `date` ===

